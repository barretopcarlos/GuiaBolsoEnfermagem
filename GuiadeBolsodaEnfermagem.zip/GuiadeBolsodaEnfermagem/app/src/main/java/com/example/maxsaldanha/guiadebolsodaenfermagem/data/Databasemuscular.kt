package com.example.maxsaldanha.guiadebolsodaenfermagem.data

import android.content.Context
import com.example.maxsaldanha.guiadebolsodaenfermagem.R
import com.example.maxsaldanha.guiadebolsodaenfermagem.domain.Doc

class Databasemuscular {
    companion object{
        fun getDocs() = listOf(
                Doc("SISTEMA MUSCULAR.pdf", R.drawable.manuaistecnicos, "SISTEMA MUSCULAR"),
                Doc("ABDOME.pdf", R.drawable.manuaistecnicos, "ABDOMEM"),
                Doc("ANTEBRAÇO.pdf", R.drawable.manuaistecnicos, "ANTEBRAÇO"),
                Doc("ATM.pdf", R.drawable.manuaistecnicos, "ATM"),
                Doc("BRAÇO.pdf", R.drawable.manuaistecnicos, "BRAÇO"),
                Doc("COXA.pdf", R.drawable.manuaistecnicos, "COXA"),
                Doc("DORSO.pdf", R.drawable.manuaistecnicos, "DORSO"),
                Doc("FACE.pdf", R.drawable.manuaistecnicos, "FACE"),
                Doc("MÃO.pdf", R.drawable.manuaistecnicos, "MÃO"),
                Doc("OMBRO.pdf", R.drawable.manuaistecnicos, "OMBRO"),
                Doc("PÉ.pdf", R.drawable.manuaistecnicos, "PÉ"),
                Doc("PERNA.pdf", R.drawable.manuaistecnicos, "PERNA"),
                Doc("PESCOÇO.pdf", R.drawable.manuaistecnicos, "PESCOÇO"),
                Doc("QUADRIL.pdf", R.drawable.manuaistecnicos, "QUADRIL"),
                Doc("TÓRAX.pdf", R.drawable.manuaistecnicos, "TÓRAX")

        )

        fun saveActualPageSP(context: Context, key: String, page: Int ){
            context
                    .getSharedPreferences("PREF", Context.MODE_PRIVATE)
                    .edit()
                    .putInt("$key-page", page)
                    .apply()
        }

        fun getActualPageSP(context: Context, key: String )
                = context
                .getSharedPreferences("PREF", Context.MODE_PRIVATE)
                .getInt("$key-page", 0)

    }
}
