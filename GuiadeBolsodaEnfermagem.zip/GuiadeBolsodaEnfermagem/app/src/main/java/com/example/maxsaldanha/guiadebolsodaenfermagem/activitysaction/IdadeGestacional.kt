package com.example.maxsaldanha.guiadebolsodaenfermagem.activitysaction

import android.graphics.Color
import android.os.Build
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import android.view.MenuItem
import android.view.View
import android.widget.EditText
import com.example.maxsaldanha.guiadebolsodaenfermagem.Calculos
import com.example.maxsaldanha.guiadebolsodaenfermagem.R
import java.lang.Integer.parseInt
import java.util.*

/* Informativo

Métodos para Cálculo da Idade Gestacional (IG) a) Quando a data da última menstruação (DUM) é conhecida:
• uso do calendário - contar o número de semanas a partir do 1o dia da última menstruação ate a data
da consulta.

http://bvsms.saude.gov.br/bvs/publicacoes/cd04_11.pdf

 */

class IdadeGestacional:
        AppCompatActivity(),
        Calculos {
    //Variável para conversão de ano e mês.
    private val ano:Double = 365.25
    private val mes:Double = 30.416666667

    //Variáveis, componentes do XML
    private lateinit var diaIg:EditText
    private lateinit var mesIg:EditText
    private lateinit var anoIg:EditText
    private lateinit var resultIg:EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_idade_gestacional)

        //seta a cor Windows StatusBar
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.statusBarColor = Color.rgb(64,174,203)
        }

        //ToolBar não default
        val toolbar:Toolbar=findViewById(R.id.my_toolbar)
        setSupportActionBar(toolbar)

        //Configurações da Toolbar
        supportActionBar!!.title="IDADE GESTACIONAL"
        supportActionBar!!.setHomeButtonEnabled(true) // Habilita botão de voltar
        supportActionBar!!.setDisplayHomeAsUpEnabled(true) // Torna o iconce visível
        supportActionBar!!.setDisplayShowHomeEnabled(true) // Torna o botão visível

        //Captura o dado informado no XML
        diaIg = findViewById(R.id.et_dia_ig)
        mesIg = findViewById(R.id.et_mes_ig)
        anoIg = findViewById(R.id.et_ano_ig)
        resultIg = findViewById(R.id.et_result_ig)

        //Método focus para capturar o dado inserido após a confirmação, sem botão de ação.
        diaIg.onFocusChangeListener = View.OnFocusChangeListener { _, _ ->
            calcular()
        }
        mesIg.onFocusChangeListener = View.OnFocusChangeListener { _, _ ->
            calcular()
        }
        anoIg.onFocusChangeListener = View.OnFocusChangeListener { _, _ ->
            calcular()
        }
    }

    //Botão de voltar no ToolBar, retorna a home anterior a activity
    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        val id = item!!.itemId
        return when (id) {
            android.R.id.home -> {
                finish()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
    //Método abstrato, herdado da interface
    override fun calcular() {

        try {

            val calendar = Calendar.getInstance()

            val diah = calendar.get(Calendar.DAY_OF_MONTH) //Captura o dia do sistema
            val mesh = calendar.get(Calendar.MONTH) + 1 //Captura o mês do sistema, acrescido para ajuste
            val anoh = calendar.get(Calendar.YEAR) //Captura o ano do sistema

            val diaig: Int = parseInt(diaIg.text.toString()) //Captura o dia digitado pelo usuário
            val mesig: Int = parseInt(mesIg.text.toString()) //Captura o mês digitado pelo usuário
            val anoig: Int = parseInt(anoIg.text.toString()) //Captura o ano digitado pelo usuário

            //Condição de teste para quanto a data e mês com valor absurdo
            when {
                (mesig == 1 || mesig == 3 ||  mesig == 5 || mesig == 7 || mesig == 8 ||
                        mesig == 10 || mesig == 12) && diaig > 31 -> resultIg.setText("Dia maior do que 31")
                (mesig == 4 || mesig == 6 || mesig == 9 || mesig == 11) && diaig > 30 -> resultIg.setText("Dia maior do que 30")
                mesig == 2 && anoig%4 == 0 && diaig > 29 -> resultIg.setText("Dia maior do que 29")
                mesig == 2 && anoig%4 != 0 && diaig > 28 -> resultIg.setText("Dia maior do que 28")
                mesig > 12 -> resultIg.setText("Mês maior do que 12")
                diaig >= diah && mesig >= mesh && anoig >= anoh -> resultIg.setText("DUM superior a data atual")
                anoig > anoh -> resultIg.setText("DUM superior a data atual")
                mesig > mesh && anoig >= anoh -> resultIg.setText("DUM superior a data atual")
                else -> {

                    val dumig:Double = diaig+(mesig*mes)+(anoig*ano) //Converte dias
                    val hojeig:Double = diah+(mesh*mes)+(anoh*ano) //Converte dias

                    val diferenca = hojeig -dumig //Calcula a diferença entre datas

                    val semana = diferenca/7 //Converte dias em semanas
                    val dias = diferenca%7 //Restante em dias

                    if (semana > 42) {

                        resultIg.setText("IG superior 42 semanas")

                    }
                    else {

                        resultIg.setText("IG: " +semana.toInt() +" semana(s) e " +dias.toInt() +" dia(s)")

                    }
                }
            }
        }
        catch (e:Exception){
            e.message
        }
    }
}