package com.example.maxsaldanha.guiadebolsodaenfermagem.activityprincipais

import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import android.view.MenuItem
import android.widget.AdapterView
import android.widget.GridView
import com.example.maxsaldanha.guiadebolsodaenfermagem.R
import com.example.maxsaldanha.guiadebolsodaenfermagem.activitysaction.*
import com.example.maxsaldanha.guiadebolsodaenfermagem.adapter.GridViewItemMenuAdpaterGroup
import com.example.maxsaldanha.guiadebolsodaenfermagem.domain.ItemMenuGrid

/*
    Classe principal com os cálculos disponíveis na aplicação.
 */
class MainActivityCalculos:
        AppCompatActivity() {

    var adapter: GridViewItemMenuAdpaterGroup? = null //Adapta o item no GridView
    var itemList = ArrayList<ItemMenuGrid>() //Array com base na classe parâmetro

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.main_activity_calculos)

        //seta a cor Windows StatusBar
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.statusBarColor = Color.rgb(64,174,203)
        }

        //ToolBar não default
        val toolbar:Toolbar=findViewById(R.id.my_toolbar)
        setSupportActionBar(toolbar)

        //Configurações da Toolbar
        supportActionBar!!.title="CÁLCULOS"
        supportActionBar!!.setHomeButtonEnabled(true)
        supportActionBar!!.setDisplayHomeAsUpEnabled(true)
        supportActionBar!!.setDisplayShowHomeEnabled(true)

        //Array de preenchimento do GridView
        itemList.add(ItemMenuGrid("INSULINA",R.drawable.insulina))
        itemList.add(ItemMenuGrid("GOTEJAMENTO",R.drawable.gotejamento))
        itemList.add(ItemMenuGrid("IMC", R.drawable.imc))
        itemList.add(ItemMenuGrid("DPP", R.drawable.parto))
        itemList.add(ItemMenuGrid("REGRA DE TRÊS", R.drawable.dose))
        itemList.add(ItemMenuGrid("IDADE ", R.drawable.idade))
        itemList.add(ItemMenuGrid("IDADE GESTACIONAL", R.drawable.idade_gest))
        itemList.add(ItemMenuGrid("SUPERFÍCIE QUEIMADA",R.drawable.area))
        itemList.add(ItemMenuGrid("REPOSIÇÃO VOLÊMICA", R.drawable.volemica))
        itemList.add(ItemMenuGrid("ESCALA APGAR", R.drawable.apgar))
        itemList.add(ItemMenuGrid("ESCALA GASGLOW", R.drawable.gasglow))
        itemList.add(ItemMenuGrid("ESCALA RASS", R.drawable.rass))

        adapter = GridViewItemMenuAdpaterGroup(this,itemList) //Definição da adapter preenchida na classe com items referenciados

        val gridView: GridView =findViewById(R.id.gr_calculos) //Instância o gridview ao id no xml
        gridView.adapter = adapter //Seta o modelo da adapter no GridView

        //Evento de click na tela
        gridView.onItemClickListener =
                AdapterView.OnItemClickListener { _, _, position, _ ->

                    when(position){
                        0 -> {
                            val i = Intent(this, DoseInsulina::class.java)
                            startActivity(i)
                        }
                        1 -> {
                            val i = Intent(this, Gotejamento::class.java)
                            startActivity(i)
                        }
                        2 -> {
                            val i = Intent(this, IndiceMassaCorporal::class.java)
                            startActivity(i)
                        }
                        3 -> {
                            val i = Intent(this, DataProvavelParto::class.java )
                            startActivity(i)
                        }
                        4 -> {
                            val i = Intent(this, RegraDeTres::class.java)
                            startActivity(i)
                        }
                        5 -> {
                            val i = Intent(this, Idade::class.java)
                            startActivity(i)
                        }
                        6 -> {
                            val i = Intent(this, IdadeGestacional::class.java)
                            startActivity(i)
                        }
                        7 -> {
                            val i = Intent(this, SuperficieQueimada::class.java )
                            startActivity(i)
                        }
                        8 -> {
                            val i = Intent(this, ReposicaoVolemica::class.java )
                            startActivity(i)
                        }
                        9 -> {
                            val i = Intent(this, EscalaApgar::class.java)
                            startActivity(i)
                        }
                        10 -> {
                            val i = Intent(this, EscalaGlasgow::class.java)
                            startActivity(i)
                        }
                        11 -> {
                            val i = Intent(this, EscalaRass::class.java)
                            startActivity(i)
                        }

                    }
                }
    }

    //Botão de voltar no ToolBar, retorna a home anterior a activity
    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        return when (item!!.itemId) {
            android.R.id.home -> {
                finish()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}


