package com.example.maxsaldanha.guiadebolsodaenfermagem

import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.view.View.SYSTEM_UI_FLAG_FULLSCREEN
import android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION


class TelaActivity:
        AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.tela_activity)

        val decorView = window.decorView

        val uiOptions = SYSTEM_UI_FLAG_HIDE_NAVIGATION or SYSTEM_UI_FLAG_FULLSCREEN

        decorView.systemUiVisibility = uiOptions


        //seta a cor Windows StatusBar
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.statusBarColor = Color.rgb(104,201,220)
        }

        val i = Intent(this, MainActivity::class.java)

        val timer = object : Thread() {
            override fun run() {
                try {
                    sleep(3000)
                }
                catch (e: InterruptedException) {
                    e.printStackTrace()
                }
                finally {
                    startActivity(i)
                    finish()
                }
            }
        }
        timer.start()
    }
}