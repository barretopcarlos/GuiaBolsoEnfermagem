package com.example.maxsaldanha.guiadebolsodaenfermagem.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.maxsaldanha.guiadebolsodaenfermagem.R
import com.example.maxsaldanha.guiadebolsodaenfermagem.domain.ItemMenuLista

class RecyclerViewItemAdapterLista(
        private val context: Context,
        private val itemList: List<ItemMenuLista>) :
        RecyclerView.Adapter<RecyclerViewItemAdapterLista.ViewHolder>() {


    override fun onCreateViewHolder(
            parent: ViewGroup,
            viewType: Int) : ViewHolder {

        val v = LayoutInflater
                .from(context)
                .inflate(R.layout.item_lista_termosigla, parent, false)

        return ViewHolder(v)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.setData(itemList[position])
    }

    override fun getItemCount(): Int {
        return itemList.size
    }

    inner class ViewHolder(itemView: View) :
            RecyclerView.ViewHolder(itemView){

        var ivPriority: TextView
        var tvDate: TextView


        init {
            ivPriority = itemView.findViewById(R.id.tv_titulo_lista)
            tvDate = itemView.findViewById(R.id.tv_texto_lista)

        }

        fun setData(item: ItemMenuLista) {
            ivPriority.text = item.titulo
            tvDate.text = item.texto
        }
    }
}

