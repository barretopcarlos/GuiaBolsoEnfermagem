package com.example.maxsaldanha.guiadebolsodaenfermagem.data

import android.content.Context
import com.example.maxsaldanha.guiadebolsodaenfermagem.R
import com.example.maxsaldanha.guiadebolsodaenfermagem.domain.Doc

class Databasearticular {
    companion object{
        fun getDocs() = listOf(
                Doc("articularanfiartroses.pdf", R.drawable.manuaistecnicos, "ANFIARTROSES"),
                Doc("articularatm.pdf", R.drawable.manuaistecnicos, "ATM"),
                Doc("articularcolunavertebral.pdf", R.drawable.manuaistecnicos, "COLUNA VERTEBRAL"),
                Doc("articularcotovelo.pdf", R.drawable.manuaistecnicos, "COTOVELO"),
                Doc("articulardiartroses.pdf", R.drawable.manuaistecnicos, "DIARTROSES"),
                Doc("articularjoelho.pdf", R.drawable.manuaistecnicos, "JOELHO"),
                Doc("articularombro.pdf", R.drawable.manuaistecnicos, "OMBRO"),
                Doc("articularpunho.pdf", R.drawable.manuaistecnicos, "PUNHO"),
                Doc("articularquadril.pdf", R.drawable.manuaistecnicos, "QUADRIL"),
                Doc("articularsinartroses.pdf", R.drawable.manuaistecnicos, "SINARTROSES"),
                Doc("articulartornozelo.pdf", R.drawable.manuaistecnicos, "TORNOZELO")

        )

        fun saveActualPageSP(context: Context, key: String, page: Int ){
            context
                    .getSharedPreferences("PREF", Context.MODE_PRIVATE)
                    .edit()
                    .putInt("$key-page", page)
                    .apply()
        }

        fun getActualPageSP(context: Context, key: String )
                = context
                .getSharedPreferences("PREF", Context.MODE_PRIVATE)
                .getInt("$key-page", 0)

    }
}
