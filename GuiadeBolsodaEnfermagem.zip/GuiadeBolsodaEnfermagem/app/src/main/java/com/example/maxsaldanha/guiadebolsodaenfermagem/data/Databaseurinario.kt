package com.example.maxsaldanha.guiadebolsodaenfermagem.data

import android.content.Context
import com.example.maxsaldanha.guiadebolsodaenfermagem.R
import com.example.maxsaldanha.guiadebolsodaenfermagem.domain.Doc

class Databaseurinario {
    companion object{
        fun getDocs() = listOf(
                Doc("SISTEMA URINÁRIO.pdf", R.drawable.manuaistecnicos, "SISTEMA URINÁRIO"),
                Doc("BEXIGA.pdf", R.drawable.manuaistecnicos, "BEXIGA"),
                Doc("RIM.pdf", R.drawable.manuaistecnicos, "RIM"),
                Doc("URETER.pdf", R.drawable.manuaistecnicos, "URETER"),
                Doc("URETRA FEMININA.pdf", R.drawable.manuaistecnicos, "URETRA FEMININA"),
                Doc("URETRA MASCULINA.pdf", R.drawable.manuaistecnicos, "URETRA MASCULINA")
        )fun saveActualPageSP(context: Context, key: String, page: Int ){
            context
                    .getSharedPreferences("PREF", Context.MODE_PRIVATE)
                    .edit()
                    .putInt("$key-page", page)
                    .apply()
        }

        fun getActualPageSP(context: Context, key: String )
                = context
                .getSharedPreferences("PREF", Context.MODE_PRIVATE)
                .getInt("$key-page", 0)

    }
}
