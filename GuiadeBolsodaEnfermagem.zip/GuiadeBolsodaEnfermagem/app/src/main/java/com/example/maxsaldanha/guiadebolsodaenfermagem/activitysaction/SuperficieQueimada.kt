package com.example.maxsaldanha.guiadebolsodaenfermagem.activitysaction

import android.graphics.Color
import android.graphics.drawable.Drawable
import android.os.Build
import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import android.view.MenuItem
import android.widget.*
import com.example.maxsaldanha.guiadebolsodaenfermagem.Calculos
import com.example.maxsaldanha.guiadebolsodaenfermagem.R

/* Informativo:
Extensão da queimadura (superfície corpórea queimada – SCQ): Regra dos nove (urgência)

Fonte: Fonte: GOMES, Dino R.; SERRA, Maria Cristina; PELLON, Marco A. Tratado de Queimaduras:
um guia prático. São José, SC: Revinter, 1997.

http://bvsms.saude.gov.br/bvs/publicacoes/cartilha_tratamento_emergencia_queimaduras.pdf
 */

class SuperficieQueimada:
        AppCompatActivity(),
        Calculos {
    //Variáveis do calculo de SQ
    private var pcabeca = 0
    private var ptroncoFrente = 0
    private var ptroncoCosta = 0
    private var pbracoEsq = 0
    private var pbracoDir = 0
    private var pvirilia = 0
    private var ppernaEsq = 0
    private var ppernaDir = 0

    //Variáveis, componentes do XML
    private lateinit var cabeca: CheckBox
    private lateinit var troncoFrente: CheckBox
    private lateinit var troncoCosta: CheckBox
    private lateinit var bracoEsq: CheckBox
    private lateinit var bracoDir: CheckBox
    private lateinit var virilia: CheckBox
    private lateinit var pernaEsq: CheckBox
    private lateinit var pernaDir: CheckBox
    private lateinit var calscq: Button
    private lateinit var rgtamanho: RadioGroup
    private lateinit var rbbebe:RadioButton
    private lateinit var rbadulto:RadioButton
    private lateinit var imagem:ImageView
    private lateinit var adulto:Drawable
    private lateinit var bebe:Drawable
    private lateinit var padrao:Drawable

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_superficie_queimada)

        //seta a cor Windows StatusBar
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.statusBarColor = Color.rgb(64, 174, 203)
        }

        //ToolBar não default
        val toolbar: Toolbar = findViewById(R.id.my_toolbar)
        setSupportActionBar(toolbar)

        //Configurações da Toolbar
        supportActionBar!!.title = "SUPERFÍCIE QUEIMADA"
        supportActionBar!!.setHomeButtonEnabled(true)
        supportActionBar!!.setDisplayHomeAsUpEnabled(true)
        supportActionBar!!.setDisplayShowHomeEnabled(true)

        //Captura o dado informado no XML CheckBox
        cabeca = findViewById(R.id.cb_cabeca)
        troncoFrente = findViewById(R.id.cb_trom_fren)
        troncoCosta = findViewById(R.id.cb_tron_costa)
        bracoEsq = findViewById(R.id.cb_bra_esq)
        bracoDir = findViewById(R.id.cb_bra_dir)
        virilia = findViewById(R.id.cb_virilia)
        pernaEsq = findViewById(R.id.cb_perna_esq)
        pernaDir = findViewById(R.id.cb_perna_dir)

        calscq = findViewById(R.id.bt_scq) //Botão de calcular

        //Captura o dado informado no XML RadioGroup
        rgtamanho = findViewById(R.id.rg_tamanho)
        rbbebe = findViewById(R.id.rb_bebe)
        rbadulto = findViewById(R.id.rb_adulto)

        //Definição das imagens para serem alternadas
        imagem = findViewById(R.id.imageViewSCQ)
        adulto = this.getDrawable(R.drawable.corpo)!!
        bebe = this.getDrawable(R.drawable.fundocalculo)!!
        padrao = this.getDrawable(R.drawable.fundotelaprincipal)!!

        //Método onClick para validar se ocorreu seleção de checkbox anterior a seleção do radiobutton
        cabeca.setOnClickListener {
            validarCheckbox()
        }
        troncoFrente.setOnClickListener {
            validarCheckbox()
        }
        troncoCosta.setOnClickListener {
            validarCheckbox()
        }
        bracoDir.setOnClickListener {
            validarCheckbox()
        }
        bracoEsq.setOnClickListener {
            validarCheckbox()
        }
        virilia.setOnClickListener {
            validarCheckbox()
        }
        pernaDir.setOnClickListener {
            validarCheckbox()
        }
        pernaEsq.setOnClickListener {
            validarCheckbox()
        }

        //Funções de manutenção da classe
        limparSelecao()
        imagemPadrao()

        //Bloco de teste para o cálculo de acordo com a superfície corporal selecionada
        try {
            rgtamanho.setOnCheckedChangeListener { _, checkedId ->
                when (checkedId) {
                    R.id.rb_bebe -> {
                        //Evento do checkbox
                        imagem.setImageDrawable(bebe)

                        cabeca.setOnCheckedChangeListener { _, isChecked ->
                            pcabeca = when {
                                isChecked -> 21
                                else -> 0
                            }
                        }
                        troncoCosta.setOnCheckedChangeListener { _, isChecked ->
                            ptroncoCosta = when {
                                isChecked -> 18
                                else -> 0
                            }
                        }
                        troncoFrente.setOnCheckedChangeListener { _, isChecked ->
                            ptroncoFrente = when {
                                isChecked -> 18
                                else -> 0
                            }
                        }
                        bracoEsq.setOnCheckedChangeListener { _, isChecked ->
                            pbracoEsq = when {
                                isChecked -> 9
                                else -> 0
                            }
                        }
                        bracoDir.setOnCheckedChangeListener { _, isChecked ->
                            pbracoDir = when {
                                isChecked -> 9
                                else -> 0
                            }
                        }
                        virilia.setOnCheckedChangeListener { _, isChecked ->
                            pvirilia = when {
                                isChecked -> 1
                                else -> 0
                            }
                        }
                        pernaDir.setOnCheckedChangeListener { _, isChecked ->
                            ppernaDir = when {
                                isChecked -> 12
                                else -> 0
                            }
                        }
                        pernaEsq.setOnCheckedChangeListener { _, isChecked ->
                            ppernaEsq = when {
                                isChecked -> 12
                                else -> 0
                            }
                        }
                    }

                    R.id.rb_adulto -> {
                        //Evento do checkbox
                        imagem.setImageDrawable(adulto)

                        cabeca.setOnCheckedChangeListener { _, isChecked ->
                            pcabeca = when {
                                isChecked -> 9
                                else -> 0
                            }
                        }
                        troncoCosta.setOnCheckedChangeListener { _, isChecked ->
                            ptroncoCosta = when {
                                isChecked -> 18
                                else -> 0
                            }
                        }
                        troncoFrente.setOnCheckedChangeListener { _, isChecked ->
                            ptroncoFrente = when {
                                isChecked -> 18
                                else -> 0
                            }
                        }
                        bracoEsq.setOnCheckedChangeListener { _, isChecked ->
                            pbracoEsq = when {
                                isChecked -> 9
                                else -> 0
                            }
                        }
                        bracoDir.setOnCheckedChangeListener { _, isChecked ->
                            pbracoDir = when {
                                isChecked -> 9
                                else -> 0
                            }
                        }
                        virilia.setOnCheckedChangeListener { _, isChecked ->
                            pvirilia = when {
                                isChecked -> 1
                                else -> 0
                            }
                        }
                        pernaDir.setOnCheckedChangeListener { _, isChecked ->
                            ppernaDir = when {
                                isChecked -> 18
                                else -> 0
                            }
                        }
                        pernaEsq.setOnCheckedChangeListener { _, isChecked ->
                            ppernaEsq = when {
                                isChecked -> 18
                                else -> 0
                            }
                        }
                    }
                }
            }
            calscq.setOnClickListener {
                calcular()
                limparSelecao()
                imagemPadrao()
            }
        } catch (e: Exception) {
            e.message
        }
    }
    //Botão de voltar no ToolBar, retorna a home anterior a activity
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id = item.itemId
        return when (id) {
            android.R.id.home -> {
                finish()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
    //Método abstrato, herdado da interface
    override fun calcular() {
            //Cálculo para definir a porcentagem de superfície corporal queimada, segundo a regra dos 9

        val scq = pcabeca + ptroncoCosta + ptroncoFrente + pvirilia + pbracoDir + pbracoEsq + ppernaEsq + ppernaDir

        if (!rbbebe.isChecked && !rbadulto.isChecked){
            val dialog = AlertDialog.Builder(this, R.style.MyDialogTheme)
                    .setTitle("SUPERFÍCIE CORPORAL QUEIMADA")
                    .setMessage("SELECIONE A SUPERFÍCIE CORPORAL")
                    .setNegativeButton("FECHAR") { _, _ -> }
            dialog.show()

        }else if (scq == 0){
            val dialog = AlertDialog.Builder(this, R.style.MyDialogTheme)
                    .setTitle("SUPERFÍCIE CORPORAL QUEIMADA")
                    .setMessage("SELECIONE UMA OU MAIS AŔEAS CORPORAIS")
                    .setNegativeButton("FECHAR") { _, _ -> }
            dialog.show()
            limparSelecao()

        }else{
            val dialog = AlertDialog.Builder(this, R.style.MyDialogTheme)
                    .setTitle("SUPERFÍCIE CORPORAL QUEIMADA")
                    .setMessage("""PORCENTAGEM: $scq""")
                    .setNegativeButton("FECHAR") { _, _ -> }
            dialog.show()
        }
    }
    //Função para resetar as seleções anteriores
    fun limparSelecao() {

        cabeca.isChecked = false
        pernaDir.isChecked = false
        pernaEsq.isChecked = false
        bracoDir.isChecked = false
        bracoEsq.isChecked = false
        virilia.isChecked = false
        troncoCosta.isChecked = false
        troncoFrente.isChecked = false
        rgtamanho.clearCheck()
    }
    //Ajusta a imagem para imagem default quando nenhuma superfície selecionada
    fun imagemPadrao(){

        if (!rbbebe.isChecked && !rbadulto.isChecked){
            imagem.setImageDrawable(padrao)
        }
    }
    //Valida se o usuário selecionou um checkbox sem um radiobutton selecionado
    fun validarCheckbox(){

        if(!rbadulto.isChecked && !rbbebe.isChecked){

            val dialog = AlertDialog.Builder(this, R.style.MyDialogTheme)
                    .setTitle("SUPERFÍCIE CORPORAL QUEIMADA")
                    .setMessage("SELECIONE A SUPERFICIE CORPORAL")
                    .setNegativeButton("FECHAR") { _, _ -> }
            dialog.show()
            limparSelecao()
        }
    }
}
