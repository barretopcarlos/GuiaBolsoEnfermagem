package com.example.maxsaldanha.guiadebolsodaenfermagem.activitysaction

import android.graphics.Color
import android.os.Build
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import android.view.MenuItem
import android.view.View
import android.widget.EditText
import com.example.maxsaldanha.guiadebolsodaenfermagem.Calculos
import com.example.maxsaldanha.guiadebolsodaenfermagem.R
import java.lang.Double.parseDouble
import java.text.DecimalFormat

/* Informativo
    Na regra de três simples trabalha-se com três elementos conhecidos, e a partir deles
    determina-se o 4º elemento. Algumas regrinhas práticas podem auxiliar-nos no cálculo,

    Fonte: http://bvsms.saude.gov.br/bvs/publicacoes/profae/pae_cad3.pdf
 */

class RegraDeTres:
        AppCompatActivity(),
        Calculos {

    //Variáveis, componentes do XML
    private lateinit var dosepresc:EditText
    private lateinit var diluente:EditText
    private lateinit var frasco:EditText
    private lateinit var resltufrac:EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_regra_de_tres)

        //seta a cor Windows StatusBar
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.statusBarColor = Color.rgb(64,174,203)
        }

        //ToolBar não default
        val toolbar:Toolbar=findViewById(R.id.my_toolbar)
        setSupportActionBar(toolbar)

        //Configurações da Toolbar
        supportActionBar!!.title="REGRA DE TRÊS"
        supportActionBar!!.setHomeButtonEnabled(true) // Habilita botão de voltar
        supportActionBar!!.setDisplayHomeAsUpEnabled(true) // Torna o iconce visível
        supportActionBar!!.setDisplayShowHomeEnabled(true) // Torna o botão visível

        //Captura o dado informado no XML
        dosepresc=findViewById(R.id.et_dose_presc)
        diluente=findViewById(R.id.et_diluente)
        frasco=findViewById(R.id.et_frasco)
        resltufrac=findViewById(R.id.result_dose_frac)

        //Método focus para capturar o dado inserido após a confirmação, sem botão de ação.
        dosepresc.onFocusChangeListener= View.OnFocusChangeListener { _, _ ->
            calcular()
        }
        diluente.onFocusChangeListener = View.OnFocusChangeListener { _, _ ->
            calcular()
        }
        frasco.onFocusChangeListener = View.OnFocusChangeListener { _, _ ->
            calcular()
        }
    }

    //Botão de voltar no ToolBar, retorna a home anterior a activity
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id = item.itemId
        return when (id) {
            android.R.id.home -> {
                finish()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    //Método abstrato, herdado da interface
    override fun calcular(){

        try {
            //Conversão de tipo de variável
            val dose:Double = parseDouble(dosepresc.text.toString())
            val diluiten:Double = parseDouble(diluente.text.toString())
            val frasco:Double = parseDouble(frasco.text.toString())

            if((diluiten>20)||(dose>9999)||(frasco>9999)){

                resltufrac.setText("Verifique o valor digitado!")

            }
            else{
                //Fórmula
                val dosagem:Double = (dose*diluiten)/frasco

                // acerta a quantidade de casas decimais
                val decimalFormat = DecimalFormat("#.#")

                //Resultado setado num EditText
                resltufrac.setText("Aplicar "+ decimalFormat.format(dosagem).toString() +" ml")

            }
        }
        catch (e:Exception){
            e.message
        }
    }
}