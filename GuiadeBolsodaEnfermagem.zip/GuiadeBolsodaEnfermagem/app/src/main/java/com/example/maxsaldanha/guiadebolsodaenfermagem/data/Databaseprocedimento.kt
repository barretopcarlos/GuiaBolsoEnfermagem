package com.example.maxsaldanha.guiadebolsodaenfermagem.data

import android.content.Context
import com.example.maxsaldanha.guiadebolsodaenfermagem.R
import com.example.maxsaldanha.guiadebolsodaenfermagem.domain.Doc

/*
Referência Bibliográfica: http://bvsms.saude.gov.br/bvs/publicacoes/profae/pae_cad3.pdf
 */
class Databaseprocedimento {
    companion object{
        fun getDocs() = listOf(

                Doc("Administrando medicamentos por via intramuscular.pdf", R.drawable.procedimentos, "Administrando medicamentos por via intramuscular"),
                Doc("Administrando medicamentos por via oral e sublingual.pdf", R.drawable.procedimentos, "Administrando medicamentos por via oral e sublingual"),
                Doc("Administrando medicamentos por via parenteral.pdf", R.drawable.procedimentos, "Administrando medicamentos por via parenteral"),
                Doc("Administrando medicamentos por via retal.pdf", R.drawable.procedimentos, "Administrando medicamentos por via retal"),
                Doc("Administrando medicamentos tópicos por via cutânea, ocular, nasal, otológica e vaginal.pdf", R.drawable.procedimentos, "Administrando medicamentos tópicos por via cutânea, ocular, nasal, otológica e vaginal."),
                Doc("Antibióticos.pdf", R.drawable.procedimentos, "Antibióticos "),
                Doc("Apresentação de medicamentos.pdf", R.drawable.procedimentos, "Apresentação de medicamentos"),
                Doc("Apresentação de medicamentos –  Medicamentos antivirais.pdf", R.drawable.procedimentos, "Apresentação de medicamentos –  Medicamentos antivirais"),
                Doc("Apresentação de medicamentos – Analgésicos, antipiréticos e anti-inflamatórios.pdf", R.drawable.procedimentos, "Apresentação de medicamentos – Analgésicos, antipiréticos e anti-inflamatórios "),
                Doc("Assistência ao morto.pdf", R.drawable.procedimentos, "Assistência ao morto"),
                Doc("Assistência ao paciente grave e ao morto.pdf", R.drawable.procedimentos, "Assistência ao paciente grave e ao morto"),
                Doc("Atendendo o paciente no hospital.pdf", R.drawable.procedimentos, "Atendendo o paciente no hospital."),
                Doc("Atuação da Equipe de enfermagem na prevenção e controle das principais infecções hospitalares.pdf", R.drawable.procedimentos, "Atuação da Equipe de enfermagem na prevenção e controle das principais infecções hospitalares"),
                Doc("Atendendo o paciente no hospital.pdf", R.drawable.procedimentos, "Atendendo o paciente no hospital."),
                Doc("Atuação da Equipe de enfermagem na prevenção e controle das principais infecções hospitalares .pdf", R.drawable.procedimentos, "Atuação da Equipe de enfermagem na prevenção e controle das principais infecções hospitalares "),
                Doc("Calçando e descalçando luvas estéreis.pdf", R.drawable.procedimentos, "Calçando e descalçando luvas estéreis"),
                Doc("Cálculo de gotejamento de infusão venosa.pdf", R.drawable.procedimentos, "Cálculo de gotejamento de infusão venosa"),
                Doc("Cálculo de medicação.pdf", R.drawable.procedimentos, "Cálculo de medicação"),
                Doc("Cálculo de medicação utilizando a porcentagem.pdf", R.drawable.procedimentos, "Cálculo de medicação utilizando a porcentagem"),
                Doc("Cálculo de medicação utilizando a regra de três simples.pdf", R.drawable.procedimentos, "Cálculo de medicação utilizando a regra de três simples"),
                Doc("Cânula de oxigênio e Máscara de oxigênio.pdf", R.drawable.procedimentos, "Cânula de oxigênio e Máscara de oxigênio"),
                Doc("Caracterizando a Enfermagem.pdf", R.drawable.procedimentos, "Caracterizando a Enfermagem"),
                Doc("Classificação das áreas hospitalares.pdf", R.drawable.procedimentos, "Classificação das áreas hospitalares"),
                Doc("Classificação de artigos hospitalares.pdf", R.drawable.procedimentos, "Classificação de artigos hospitalares"),
                Doc("Coletando urina por jato médio.pdf", R.drawable.procedimentos, "Coletando urina por jato médio"),
                Doc("Colhendo sangue para hemocultura.pdf", R.drawable.procedimentos, "Colhendo sangue para hemocultura "),
                Doc("Controlando a frequência respiratória.pdf", R.drawable.procedimentos, "Controlando a frequência respiratória"),
                Doc("Controlando a pressão arterial.pdf", R.drawable.procedimentos, "Controlando a pressão arterial "),
                Doc("Controlando o pulso.pdf", R.drawable.procedimentos, "Controlando o pulso "),
                Doc("Cuidados com a alimentação e hidratação.pdf", R.drawable.procedimentos, "Cuidados com a alimentação e hidratação "),
                Doc("Cuidados de enfermagem.pdf", R.drawable.procedimentos, "Cuidados de enfermagem"),
                Doc("Cuidados de enfermagem na alteração de temperatura corporal.pdf", R.drawable.procedimentos, "Cuidados de enfermagem na alteração de temperatura corporal "),
                Doc("Curativo - infecções relacionadas ao uso de cateteres intravasculares.pdf", R.drawable.procedimentos, "Curativo - infecções relacionadas ao uso de cateteres intravasculares "),
                Doc("Fonte de infecção relacionada a artigos hospitalares.pdf", R.drawable.procedimentos, "Fonte de infecção relacionada a artigos hospitalares"),
                Doc("Fonte de infecção relacionada à equipe de saúde.pdf", R.drawable.procedimentos, "Fonte de infecção relacionada à equipe de saúde"),
                Doc("Fonte de infecção relacionada ao ambiente.pdf", R.drawable.procedimentos, "Fonte de infecção relacionada ao ambiente"),
                Doc("Fonte de infecção relacionada ao paciente.pdf", R.drawable.procedimentos, "Fonte de infecção relacionada ao paciente"),
                Doc("Higienizando a boca.pdf", R.drawable.procedimentos, "Higienizando a boca"),
                Doc("Identificação e Tratamento das Infecções.pdf", R.drawable.procedimentos, "Identificação e Tratamento das Infecções"),
                Doc("Implementando medidas para a identificação de infecções - Controlando a temperatura corporal.pdf", R.drawable.procedimentos, "Implementando medidas para a identificação de infecções - Controlando a temperatura corporal"),
                Doc("Implementando medidas para a identificação de infecções - Verificando a temperatura corporal.pdf", R.drawable.procedimentos, "Implementando medidas para a identificação de infecções - Verificando a temperatura corporal"),
                Doc("Instalando o cateter vesical.pdf", R.drawable.procedimentos, "Instalando o cateter vesical "),
                Doc("Lavando as mãos.pdf", R.drawable.procedimentos, "Lavando as mãos"),
                Doc("Lavando os cabelos e o couro cabeludo.pdf", R.drawable.procedimentos, "Lavando os cabelos e o couro cabeludo"),
                Doc("Limpeza e preparo da unidade do paciente.pdf", R.drawable.procedimentos, "Limpeza e preparo da unidade do paciente."),
                Doc("Luvas esterilizadas e de procedimento.pdf", R.drawable.procedimentos, "Luvas esterilizadas e de procedimento"),
                Doc("Medidas de precaução de contato - Precauções de contato.pdf", R.drawable.procedimentos, "Medidas de precaução de contato - Precauções de contato "),
                Doc("Medidas de precaução de contato - Precauções respiratórias.pdf", R.drawable.procedimentos, "Medidas de precaução de contato - Precauções respiratórias "),
                Doc("Medidas de precaução de contato – Precauções empíricas pdf", R.drawable.procedimentos, "Medidas de precaução de contato – Precauções empíricas "),
                Doc("Medidas de precaução-padrão.pdf", R.drawable.procedimentos, "Medidas de precaução-padrão"),
                Doc("Medindo a altura e o peso no adulto .pdf", R.drawable.procedimentos, "Medindo a altura e o peso no adulto "),
                Doc("Métodos e frequência da limpeza, desinfecção e descontaminação.pdf", R.drawable.procedimentos, "Métodos e frequência da limpeza, desinfecção e descontaminação"),
                Doc("Na infecção de sítio cirúrgico.pdf", R.drawable.procedimentos, "Na infecção de sítio cirúrgico "),
                Doc("Na infecção do trato respiratório(pneumonia).pdf", R.drawable.procedimentos, "Na infecção do trato respiratório(pneumonia)"),
                Doc("Nutrição enteral.pdf", R.drawable.procedimentos, "Nutrição enteral"),
                Doc("Nutrição enteral - Administrando a dieta enteral.pdf", R.drawable.procedimentos, "Nutrição enteral - Administrando a dieta enteral"),
                Doc("Nutrição enteral – Inserindo a sonda nasogástrica.pdf", R.drawable.procedimentos, "Nutrição enteral – Inserindo a sonda nasogástrica"),
                Doc("O hospital, a assistência de enfermagem e a prevenção da infecção.pdf", R.drawable.procedimentos, "O hospital, a assistência de enfermagem e a prevenção da infecção"),
                Doc("Precauções-padrão e isolamento.pdf", R.drawable.procedimentos, "Precauções-padrão e isolamento "),
                Doc("Preparo do corpo.pdf", R.drawable.procedimentos, "Preparo do corpo"),
                Doc("Princípios da administração de medicamentos.pdf", R.drawable.procedimentos, "Princípios da administração de medicamentos"),
                Doc("Processamento de artigos hospitalares.pdf", R.drawable.procedimentos, "Processamento de artigos hospitalares"),
                Doc("Realizando a oxigenoterapia.pdf", R.drawable.procedimentos, "Realizando a oxigenoterapia"),
                Doc("Realizando curativo com luva estéril.pdf", R.drawable.procedimentos, "Realizando curativo com luva estéril"),
                Doc("Realizando curativo com pinças.pdf", R.drawable.procedimentos, "Realizando curativo com pinças"),
                Doc("Realizando o banho.pdf", R.drawable.procedimentos, "Realizando o banho"),
                Doc("Realizando o curativo através de irrigação com solução fisiológica.pdf", R.drawable.procedimentos, "Realizando o curativo através de irrigação com solução fisiológica"),
                Doc("Sistema de informação em enfermagem.pdf", R.drawable.procedimentos, "Sistema de informação em enfermagem"),
                Doc("Sistema de informação em saúde.pdf", R.drawable.procedimentos, "Sistema de informação em saúde"),
                Doc("Técnica de lavagem das mãos.pdf", R.drawable.procedimentos, "Técnica de lavagem das mãos"),
                Doc("Terapêutica medicamentosa aplicada às infecções.pdf", R.drawable.procedimentos, "Terapêutica medicamentosa aplicada às infecções"),
                Doc("Terapêutica não-medicamentosa aplicada às infecções.pdf", R.drawable.procedimentos, "Terapêutica não-medicamentosa aplicada às infecções"),
                Doc("Tipos de curativos.pdf", R.drawable.procedimentos, "Tipos de curativos "),
                Doc("Transfusão de sangue e seus componentes.pdf", R.drawable.procedimentos, "Transfusão de sangue e seus componentes"),
                Doc("Unidade do paciente.pdf", R.drawable.procedimentos, "Unidade do paciente"),
                Doc("Venóclise.pdf", R.drawable.procedimentos, "Venóclise"),
                Doc("Verificando a pressão arterial.pdf", R.drawable.procedimentos, "Verificando a pressão arterial"),
                Doc("Via endovenosa.pdf", R.drawable.procedimentos, "Via endovenosa"),
                Doc("Via intradérmica.pdf", R.drawable.procedimentos, "Via intradérmica"),
                Doc("Via intramuscular.pdf", R.drawable.procedimentos, "Via intramuscular"),
                Doc("Via subcutânea.pdf", R.drawable.procedimentos, "Via subcutânea")
        )
        fun saveActualPageSP(context: Context, key: String, page: Int ){
            context
                    .getSharedPreferences("PREF", Context.MODE_PRIVATE)
                    .edit()
                    .putInt("$key-page", page)
                    .apply()
        }

        fun getActualPageSP(context: Context, key: String )
                = context
                .getSharedPreferences("PREF", Context.MODE_PRIVATE)
                .getInt("$key-page", 0)

    }
}
