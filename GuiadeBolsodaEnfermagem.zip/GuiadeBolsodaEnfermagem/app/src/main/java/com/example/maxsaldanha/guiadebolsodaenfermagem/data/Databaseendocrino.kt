package com.example.maxsaldanha.guiadebolsodaenfermagem.data

import android.content.Context
import com.example.maxsaldanha.guiadebolsodaenfermagem.R
import com.example.maxsaldanha.guiadebolsodaenfermagem.domain.Doc

class Databaseendocrino {
    companion object{
        fun getDocs() = listOf(
                Doc("SISTEMA ENDÓCRINO.pdf", R.drawable.manuaistecnicos, "SISTEMA ENDÓCRINO"),
                Doc("GLÂNDULA PINEAL.pdf", R.drawable.manuaistecnicos, "GLÂNDULA PINEAL"),
                Doc("GLÂNDULA TIREOIDE.pdf", R.drawable.manuaistecnicos, "GLÂNDULA TIREOIDE"),
                Doc("GLÂNDULAS PARATIREOIDES.pdf", R.drawable.manuaistecnicos, "GLÂNDULAS PARATIREOIDES"),
                Doc("GLÂNDULAS SUPRARRENAIS.pdf", R.drawable.manuaistecnicos, "GLÂNDULAS SUPRARRENAIS"),
                Doc("GÔNADAS (OVÁRIOS E TESTÍCULOS).pdf", R.drawable.manuaistecnicos, "GÔNADAS (OVÁRIOS E TESTÍCULOS)"),
                Doc("HIPÓFISE.pdf", R.drawable.manuaistecnicos, "HIPÓFISE"),
                Doc("PÂNCREAS.pdf", R.drawable.manuaistecnicos, "PÂNCREAS"),
                Doc("TIMO.pdf", R.drawable.manuaistecnicos, "TIMO")

        )fun saveActualPageSP(context: Context, key: String, page: Int ){
            context
                    .getSharedPreferences("PREF", Context.MODE_PRIVATE)
                    .edit()
                    .putInt("$key-page", page)
                    .apply()
        }

        fun getActualPageSP(context: Context, key: String )
                = context
                .getSharedPreferences("PREF", Context.MODE_PRIVATE)
                .getInt("$key-page", 0)

    }
}
