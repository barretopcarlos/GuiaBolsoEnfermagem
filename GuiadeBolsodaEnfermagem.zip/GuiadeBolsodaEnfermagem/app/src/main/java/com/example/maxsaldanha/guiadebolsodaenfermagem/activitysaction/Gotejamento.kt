package com.example.maxsaldanha.guiadebolsodaenfermagem.activitysaction

import android.graphics.Color
import android.os.Build
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import android.view.MenuItem
import android.view.View
import android.widget.EditText
import com.example.maxsaldanha.guiadebolsodaenfermagem.Calculos
import com.example.maxsaldanha.guiadebolsodaenfermagem.R
import java.lang.Float.parseFloat
/* Informativo:
   Cálculo referente a relação de volume e tempo da infusão de volumes, em equipos de macrogotas,
   microgotas e BIC

   Macrogotas:  Calcular o nº de gotas que existem no frasco de solução, lembrando-se que cada ml
   equiva a 20 gotas.
   Microgotas: Calcular o nº de gotas que existem no frasco de solução, lembrando-se que cada ml
   equiva a 20 gotas. Multiplicando o número de gotas por 3, 60 microgotas.

   BIC: Bonba infusora Contínua, equipamento para gerenciar o fluxo de volumes de forma contínua e
   precisa, funciona

   Fonte: http://bvsms.saude.gov.br/bvs/publicacoes/profae/pae_cad3.pdf
    */

class Gotejamento:AppCompatActivity(),
        Calculos {

    //Variáveis, componentes do XML
    private lateinit var hora: EditText
    private lateinit var minuto: EditText
    private lateinit var volume: EditText
    private lateinit var resultadoMicro: EditText
    private lateinit var resultadoMacro: EditText
    private lateinit var resultadoBIC: EditText


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_gotejamento)

        //seta a cor Windows StatusBar
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.statusBarColor = Color.rgb(64,174,203)
        }

        //ToolBar não default
        val toolbar:Toolbar=findViewById(R.id.my_toolbar)
        setSupportActionBar(toolbar)

        //Configurações da Toolbar
        supportActionBar!!.title="GOTEJAMENTO"
        supportActionBar!!.setHomeButtonEnabled(true) // Habilita botão de voltar
        supportActionBar!!.setDisplayHomeAsUpEnabled(true) // Torna o iconce visível
        supportActionBar!!.setDisplayShowHomeEnabled(true) // Torna o botão visível

        //Captura o dado informado no XML
        hora=findViewById(R.id.et_hora_got)
        minuto=findViewById(R.id.et_minuto_got)
        volume=findViewById(R.id.et_volume_got)
        resultadoMicro=findViewById(R.id.et_result_micro)
        resultadoMacro=findViewById(R.id.et_result_macro)
        resultadoBIC=findViewById(R.id.et_result_BIC)

        //Método focus para capturar o dado inserido após a confirmação, sem botão de ação.
        volume.onFocusChangeListener = View.OnFocusChangeListener { _, _ ->
            calcular()
        }
        hora.onFocusChangeListener = View.OnFocusChangeListener { _, _ ->
            calcular()
        }
        minuto.onFocusChangeListener = View.OnFocusChangeListener { _, _ ->
            calcular()
        }
    }

    //Botão de voltar no ToolBar, retorna a home anterior a activity
    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        val id = item!!.itemId
        return when (id) {
            android.R.id.home -> {
                finish()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    //Método abstrato, herdado da interface
    override fun calcular() {

        try {
            //Conversão de tipo de variável
            val hora:Float = parseFloat(hora.text.toString())
            val minuto:Float = parseFloat(minuto.text.toString())
            val volume:Float = parseFloat(volume.text.toString())

            if ((hora>24)||(minuto>59)||(volume>9999)){

                //Resultado setado num EditText, classe Math para arrendamento para cima
                resultadoMicro.setText("Verifique o valor digitado!")
                resultadoMacro.setText("Verifique o valor digitado!")
                resultadoBIC.setText("Verifique o valor digitado!")

            }
            else{
                val tempomin:Float = hora*60+minuto //converte tempo em minutos
                val tempohor:Float = hora+minuto/60 //converte tempo em horas

                //Fórmula
                val microgota:Float = volume*60/tempomin
                val macrogota:Float = volume*20/tempomin
                val mlhora:Float = volume/tempohor

                //Resultado setado num EditText, classe Math para arrendamento para cima
                resultadoMicro.setText(Math.round(microgota).toString() + " microgts/min")
                resultadoMacro.setText(Math.round(macrogota).toString() + " macrogts/min")
                resultadoBIC.setText(Math.round(mlhora).toString() + " ml/h")

            }
        }
        catch (e: Exception) {

            e.message
        }
    }
}