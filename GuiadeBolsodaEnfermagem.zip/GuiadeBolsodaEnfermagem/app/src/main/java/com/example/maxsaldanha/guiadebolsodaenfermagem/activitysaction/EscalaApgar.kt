package com.example.maxsaldanha.guiadebolsodaenfermagem.activitysaction

import android.graphics.Color
import android.os.Build
import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import android.view.MenuItem
import android.widget.Button
import android.widget.RadioGroup
import com.example.maxsaldanha.guiadebolsodaenfermagem.Calculos
import com.example.maxsaldanha.guiadebolsodaenfermagem.R

/*
http://www.saude.pr.gov.br/arquivos/File/opdf1.pdf
 */

class EscalaApgar:
        AppCompatActivity(),
        Calculos {

    //Variáveis dos índices do APGAR
    private var atividade = 0
    private var bpm = 0
    private var cor = 0
    private var respira = 0
    private var reflexo = 0

    //Componentes no XML
    private lateinit var radioGroupAtividade: RadioGroup
    private lateinit var radioGroupbpm: RadioGroup
    private lateinit var radioGroupCor: RadioGroup
    private lateinit var radioGroupReflexo: RadioGroup
    private lateinit var radioGrouRespira: RadioGroup
    private lateinit var btapgar:Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_apgar)

        //seta a cor Windows StatusBar
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.statusBarColor = Color.rgb(64,174,203)
        }

        //ToolBar não default
        val toolbar:Toolbar=findViewById(R.id.my_toolbar)
        setSupportActionBar(toolbar)

        //Configurações da Toolbar
        supportActionBar!!.title = "ESCALA DE APGAR"
        supportActionBar!!.setHomeButtonEnabled(true) // Habilita botão de voltar
        supportActionBar!!.setDisplayHomeAsUpEnabled(true) // Torna o iconce visível
        supportActionBar!!.setDisplayShowHomeEnabled(true) // Torna o botão visível

        //Captura o dado informado no XML
        radioGroupAtividade = findViewById(R.id.rg_atividade)
        radioGroupbpm = findViewById(R.id.rg_bpm)
        radioGroupCor = findViewById(R.id.rg_cor)
        radioGroupReflexo = findViewById(R.id.rg_reflexo)
        radioGrouRespira = findViewById(R.id.rg_respira)
        btapgar = findViewById(R.id.bt_apgar)


        try {
            //Evento para calcular o indice de APGAR, segundo os sinais selecionados nos RadioGroups

            radioGroupAtividade.setOnCheckedChangeListener { _, checkedId ->
                when(checkedId){
                    R.id.rb_ativi_0 ->{
                        atividade = 0
                    }
                    R.id.rb_ativi_1 -> {
                        atividade = 1
                    }
                    R.id.rb_ativi_2 -> {
                        atividade = 2
                    }
                }
            }
            radioGroupbpm.setOnCheckedChangeListener { _, checkedId ->
                when(checkedId){
                    R.id.rb_bpm_0 -> {
                        bpm = 0
                    }
                    R.id.rb_bpm_1 -> {
                        bpm = 1
                    }
                    R.id.rb_bpm_2 -> {
                        bpm = 2
                    }
                }
            }
            radioGroupCor.setOnCheckedChangeListener { _, checkedId ->
                when(checkedId){
                    R.id.rb_cor_0 ->{
                        cor = 0
                    }
                    R.id.rb_cor_1 -> {
                        cor = 1
                    }
                    R.id.rb_cor_2 -> {
                        cor = 2
                    }
                }
            }
            radioGroupReflexo.setOnCheckedChangeListener { _, checkedId ->
                when(checkedId){
                    R.id.rb_reflexo_0 -> {
                        reflexo = 0
                    }
                    R.id.rb_reflexo_1 -> {
                        reflexo = 1
                    }
                    R.id.rb_reflexo_2 -> {
                        reflexo = 2
                    }
                }
            }
            radioGrouRespira.setOnCheckedChangeListener { _, checkedId ->
                when(checkedId){
                    R.id.rb_respira_0 ->{
                        respira = 0
                    }
                    R.id.rb_respira_1 -> {
                        respira = 1
                    }
                    R.id.rb_respira_2 -> {
                        respira = 2
                    }
                }
            }
            btapgar.setOnClickListener {

                calcular()
            }
        }
        catch (e:Exception){
            e.message
        }
    }

    //Botão de voltar no ToolBar, retorna a home anterior a activity
    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        val id = item!!.itemId
        return when (id) {
            android.R.id.home -> {
                finish()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
    //Método abstrato, herdado da interface
    override fun calcular() {

        val apgar = atividade + bpm + cor + reflexo + respira

        when {
            apgar > 7 -> {
                val dialog = AlertDialog.Builder(this, R.style.MyDialogTheme)
                        .setTitle("RESULTADO")
                        .setMessage("Índice: " +apgar +"\n \n  Apgar 8 a 10, presente em cerca de 90% " +
                                "dos recém-nascidos, significa que o bebê nasceu em ótimas condições. ")
                        .setNegativeButton("Fechar") { _, _ -> }
                dialog.show()

            }
            apgar in 5..7 -> {
                val dialog = AlertDialog.Builder(this, R.style.MyDialogTheme)
                        .setTitle("RESULTADO")
                        .setMessage("Índice: " +apgar +"\n \n  Apgar 5 a 7 significa que o bebê " +
                                "apresentou uma dificuldade leve. ")
                        .setNegativeButton("Fechar") { _, _ -> }
                dialog.show()
            }
            apgar in 3..4 -> {
                val dialog = AlertDialog.Builder(this, R.style.MyDialogTheme)
                        .setTitle("RESULTADO")
                        .setMessage("""Índice: $apgar  Apgar 3 a 4 traduz uma dificuldade de grau moderado""")
                        .setNegativeButton("Fechar") { _, _ -> }
                dialog.show()
            }
            else -> {
                val dialog = AlertDialog.Builder(this, R.style.MyDialogTheme)
                        .setTitle("RESULTADO")
                        .setMessage("Índice: $apgar Apgar 0 a 2 aponta uma dificuldade de ordem"+
                                " grave. Se estas dificuldades persistirem durante alguns minutos"+
                                " sem tratamento, podem levar a alterações metabólicas no organismo"+
                                " e anóxia. A presença de mecônio é agravante.")
                        .setNegativeButton("Fechar") { _, _ -> }
                dialog.show()
            }
        }
    }
}