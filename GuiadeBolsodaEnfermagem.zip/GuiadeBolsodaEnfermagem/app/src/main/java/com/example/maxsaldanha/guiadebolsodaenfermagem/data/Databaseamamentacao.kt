package com.example.maxsaldanha.guiadebolsodaenfermagem.data

import android.content.Context
import com.example.maxsaldanha.guiadebolsodaenfermagem.R
import com.example.maxsaldanha.guiadebolsodaenfermagem.domain.Doc

/*
http://bvsms.saude.gov.br/bvs/publicacoes/amamentacao_uso_medicamentos_2ed.pdf
 */

class Databaseamamentacao  {
    companion object{
        fun getDocs() = listOf(

                Doc(".pdf", R.drawable.amamentacao, "VITAMINAS E MINERAIS")
        )
        fun saveActualPageSP(context: Context, key: String, page: Int ){
            context
                    .getSharedPreferences("PREF", Context.MODE_PRIVATE)
                    .edit()
                    .putInt("$key-page", page)
                    .apply()
        }

        fun getActualPageSP( context: Context, key: String )
                = context
                .getSharedPreferences("PREF", Context.MODE_PRIVATE)
                .getInt("$key-page", 0)

    }
}