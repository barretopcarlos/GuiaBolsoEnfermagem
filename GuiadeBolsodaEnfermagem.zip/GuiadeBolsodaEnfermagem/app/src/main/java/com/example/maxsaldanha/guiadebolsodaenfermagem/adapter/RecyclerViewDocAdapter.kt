package com.example.maxsaldanha.guiadebolsodaenfermagem.adapter

import android.content.Context
import android.content.Intent
import androidx.recyclerview.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import com.example.maxsaldanha.guiadebolsodaenfermagem.R
import com.example.maxsaldanha.guiadebolsodaenfermagem.activityprincipais.ActivityPdf
import com.example.maxsaldanha.guiadebolsodaenfermagem.domain.Doc

/* Informe:
    Classe de adaptadora padrão da visualização dos itens no RecyclerView
 */
class RecyclerViewDocAdapter(
        private val context: Context,
        private val docList: List<Doc>) :
        RecyclerView.Adapter<RecyclerViewDocAdapter.ViewHolder>() {

    override fun onCreateViewHolder(
            parent: ViewGroup,
            viewType: Int) : ViewHolder {

        val v = LayoutInflater
                .from(context)
                .inflate(R.layout.item_doc, parent, false)

        return ViewHolder(v)

    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.setData(docList[position])
    }

    override fun getItemCount(): Int {
        return docList.size
    }

    inner class ViewHolder(itemView: View) :
            RecyclerView.ViewHolder(itemView),
            View.OnClickListener {

        private var ivCover: ImageView
        private var tvLanguage: TextView


        init {
            itemView.setOnClickListener(this)
            ivCover = itemView.findViewById(R.id.iv_cover)
            tvLanguage = itemView.findViewById(R.id.tv_language)
        }

        fun setData(doc: Doc) {
            ivCover.setImageResource( doc.imageRes )
            tvLanguage.text = doc.language
        }

        override fun onClick(view: View?) {
            val intent = Intent(context, ActivityPdf::class.java)
            intent.putExtra( Doc.DOC_KEY, docList[adapterPosition])
            context.startActivity(intent)
            }
    }
}
