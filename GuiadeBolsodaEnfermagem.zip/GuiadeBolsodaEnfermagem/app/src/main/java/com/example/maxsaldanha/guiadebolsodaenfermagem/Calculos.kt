package com.example.maxsaldanha.guiadebolsodaenfermagem
/*
    Interface para manter a anotação e ligação das classe do componente Cálculos, que possuem resultado
    mas como não se tem uma homegeinidade de atributos, para manter o padrão de assinatura, todas compartilham
    a função calcular, mas subescrevidas para suas particularidades.
    Com execeção da Classe RASS, que exibi um resultado, mas não gera cálculo, apenas uma relação de
    parametrizada quando ao estado físico e um índice.
 */
interface Calculos {

    fun calcular()
}