package com.example.maxsaldanha.guiadebolsodaenfermagem.data

import com.example.maxsaldanha.guiadebolsodaenfermagem.domain.ItemMenuLista

class Databasesigla {

    companion object{
        fun getDocs() = listOf(

                ItemMenuLista("",""),
                ItemMenuLista("",""),
                ItemMenuLista("",""),
                ItemMenuLista("",""),
                ItemMenuLista("",""),
                ItemMenuLista("",""),
                ItemMenuLista("",""),
                ItemMenuLista("",""),
                ItemMenuLista("",""),
                ItemMenuLista("",""),
                ItemMenuLista("",""),
                ItemMenuLista("","")
        )

    }
}
