package com.example.maxsaldanha.guiadebolsodaenfermagem.activitysaction

import android.graphics.Color
import android.os.Build
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import android.view.MenuItem
import android.view.View
import android.widget.EditText
import com.example.maxsaldanha.guiadebolsodaenfermagem.Calculos
import com.example.maxsaldanha.guiadebolsodaenfermagem.R
import java.lang.Integer.parseInt
import java.util.*

/* Informativo

    A classe realiza o processo de subtração de datas, considerando as particularidades do calendário,
    considerando os meses com 30, 31 e anos bissextos.
 */

class Idade:AppCompatActivity(),
        Calculos {
    //Variável para conversão de ano e mês.
    private val ano:Double = 365.25
    private val mes:Double = 30.416666667

    //Variáveis, componentes do XML
    private lateinit var resultIdade:EditText
    private lateinit var diaN:EditText
    private lateinit var mesN:EditText
    private lateinit var anoN:EditText

       override fun onCreate(savedInstanceState: Bundle?) {
           super.onCreate(savedInstanceState)
           setContentView(R.layout.activity_idade_atual)

           //seta a cor Windows StatusBar
           if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
               window.statusBarColor = Color.rgb(64,174,203)
           }

           //Tooblar no default
           val toolbar: Toolbar = findViewById(R.id.my_toolbar)
           setSupportActionBar(toolbar)

           //Configurações da Toolbar
           supportActionBar!!.title = "IDADE"
           supportActionBar!!.setHomeButtonEnabled(true) // Habilita botão de voltar
           supportActionBar!!.setDisplayHomeAsUpEnabled(true) // Torna o iconce visível
           supportActionBar!!.setDisplayShowHomeEnabled(true) // Torna o botão visível

           //Captura o dado informado no XML
           diaN = findViewById(R.id.et_dia_nasc)
           mesN = findViewById(R.id.et_mes_nasc)
           anoN = findViewById(R.id.et_ano_nasc)
           resultIdade = findViewById(R.id.et_result_idade)

           //Método focus para capturar o dado inserido após a confirmação, sem botão de ação.
           diaN.onFocusChangeListener = View.OnFocusChangeListener { _, _ ->
               calcular()
           }
           mesN.onFocusChangeListener = View.OnFocusChangeListener { _, _ ->
               calcular()
           }
           anoN.onFocusChangeListener = View.OnFocusChangeListener { _, _ ->
               calcular()
           }
       }

    //Botão de voltar no ToolBar, retorna a home anterior a activity
    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        val id = item!!.itemId
        return when (id) {
            android.R.id.home -> {
                finish()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    //Método abstrato, herdado da interface
    override fun calcular(){

       try {

           val calendar = Calendar.getInstance() //Instância do caledánrio

           val diaH = calendar.get(Calendar.DAY_OF_MONTH) //Captura dia do sistema
           val mesH = calendar.get(Calendar.MONTH)+1 //Captura mês do sistema com ajuste do índice
           val anoH = calendar.get(Calendar.YEAR) //Captura ano do sistema

           val dian:Int = parseInt(diaN.text.toString()) //Captura dia informado pelo usuário
           val mesn:Int = parseInt(mesN.text.toString()) //Captura mês informado pelo usuário
           val anon:Int = parseInt(anoN.text.toString()) //Captura ano informado pelo usuário

           //Condição de teste para quanto a data e mês com valor absurdo
           when {
               (mesn == 1 || mesn == 3 ||  mesn == 5 || mesn == 7 || mesn == 8 ||
                       mesn == 10 || mesn ==12) && dian > 31 -> resultIdade.setText("Verifique a data digitada!")
               (mesn == 4 || mesn == 6 || mesn == 9 || mesn == 11) && dian > 30 -> resultIdade.setText("Verifique a data digitada!")
               mesn == 2 && anoH%4 == 0 && dian > 29 -> resultIdade.setText("Verifique a data digitada!")
               mesn == 2 && anoH%4 != 0 && dian> 28 -> resultIdade.setText("Verifique a data digitada!")
               mesn > 12 -> resultIdade.setText("Verifique a data digitada!")
               dian > 31 || mesn > 12 || anon > anoH -> resultIdade.setText("Verifique a data digitada!")
               (dian >= diaH) && (mesn >= mesH) && (anon >= anoH) -> resultIdade.setText("Verifique a data digitada!")
               (dian <= diaH) && (mesn > mesH) && (anon >= anoH) -> resultIdade.setText("Verifique a data digitada!")
               else -> {
                   //Converte em dias a data de hoje e data de nascimento
                   val datnasc:Double = dian+(mesn*mes)+(anon*ano)
                   val hojenasc:Double = diaH+(mesH*mes)+(anoH*ano)

                   //Calcula a diferença entre as datas em dias
                   val diferenca = hojenasc - datnasc

                   //Converte a diferença em dias para anos, meses e dias
                   val anos = diferenca/ano
                   val meses= (diferenca%ano)/mes
                   val diass= (diferenca%ano)%mes

                   //Resultado setado num EditText
                   resultIdade.setText(" Idade: "+anos.toInt() + " ano(s), "+meses.toInt()
                           +" mes(es), " +diass.toInt() +" dia(s)")
               }
           }
       }
       catch (e:Exception){
           e.message
       }
    }

}
