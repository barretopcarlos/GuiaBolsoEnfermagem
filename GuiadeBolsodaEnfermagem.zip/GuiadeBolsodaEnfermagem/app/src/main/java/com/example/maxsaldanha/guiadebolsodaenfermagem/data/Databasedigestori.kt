package com.example.maxsaldanha.guiadebolsodaenfermagem.data

import android.content.Context
import com.example.maxsaldanha.guiadebolsodaenfermagem.R
import com.example.maxsaldanha.guiadebolsodaenfermagem.domain.Doc

class Databasedigestori {
    companion object{
        fun getDocs() = listOf(
                Doc("SISTEMA DIGESTÓRIO.pdf", R.drawable.manuaistecnicos, "SISTEMA DIGESTÓRIO"),
                Doc("BOCA.pdf", R.drawable.manuaistecnicos, "BOCA"),
                Doc("DENTES.pdf", R.drawable.manuaistecnicos, "DENTES"),
                Doc("ESÔFAGO.pdf", R.drawable.manuaistecnicos, "ESÔFAGO"),
                Doc("ESTÔMAGO.pdf", R.drawable.manuaistecnicos, "ESTÔMAGO"),
                Doc("FARINGE.pdf", R.drawable.manuaistecnicos, "FARINGE"),
                Doc("FÍGADO.pdf", R.drawable.manuaistecnicos, "FÍGADO"),
                Doc("INTESTINO DELGADO.pdf", R.drawable.manuaistecnicos, "INTESTINO DELGADO"),
                Doc("INTESTINO GROSSO.pdf", R.drawable.manuaistecnicos, "INTESTINO GROSSO"),
                Doc("LÍNGUA.pdf", R.drawable.manuaistecnicos, "LÍNGUA"),
                Doc("ÓRGÃOS ANEXOS.pdf", R.drawable.manuaistecnicos, "ÓRGÃOS ANEXOS"),
                Doc("PÂNCREAS.pdf", R.drawable.manuaistecnicos, "PÂNCREAS"),
                Doc("PERITÔNIO.pdf", R.drawable.manuaistecnicos, "PERITÔNIO"),
                Doc("VESÍCULA BILIAR.pdf", R.drawable.manuaistecnicos, "VESÍCULA BILIAR")

        )fun saveActualPageSP(context: Context, key: String, page: Int ){
            context
                    .getSharedPreferences("PREF", Context.MODE_PRIVATE)
                    .edit()
                    .putInt("$key-page", page)
                    .apply()
        }

        fun getActualPageSP(context: Context, key: String )
                = context
                .getSharedPreferences("PREF", Context.MODE_PRIVATE)
                .getInt("$key-page", 0)

    }
}
