package com.example.maxsaldanha.guiadebolsodaenfermagem.data

import android.content.Context
import com.example.maxsaldanha.guiadebolsodaenfermagem.R
import com.example.maxsaldanha.guiadebolsodaenfermagem.domain.Doc

class Databaseanatomia {
    companion object{
        fun getDocs() = listOf(
                Doc("circulatório.pdf", R.drawable.manuaistecnicos, "SISTEMA CIRCULATÓRIO"),
                Doc("digestivo.pdf", R.drawable.manuaistecnicos, "SISTEMA DIGESTÓRIO"),
                Doc("pdf.pdf", R.drawable.manuaistecnicos, "Sistema Endócrino"),
                Doc("ossos.pdf", R.drawable.manuaistecnicos, "Sistema Esquelético"),
                Doc("pdf.pdf", R.drawable.manuaistecnicos, "Sistema Muscular"),
                Doc("pdf.pdf", R.drawable.manuaistecnicos, "Sistema Nervoso"),
                Doc("pdf.pdf", R.drawable.manuaistecnicos, "Sistema Respiratório")
        )fun saveActualPageSP(context: Context, key: String, page: Int ){
            context
                    .getSharedPreferences("PREF", Context.MODE_PRIVATE)
                    .edit()
                    .putInt("$key-page", page)
                    .apply()
        }

        fun getActualPageSP(context: Context, key: String )
                = context
                .getSharedPreferences("PREF", Context.MODE_PRIVATE)
                .getInt("$key-page", 0)

    }
}
