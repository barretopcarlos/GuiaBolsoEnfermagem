package com.example.maxsaldanha.guiadebolsodaenfermagem.activityprincipais

import android.graphics.Color
import android.os.Build
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import android.view.MenuItem
import com.example.maxsaldanha.guiadebolsodaenfermagem.R
import com.example.maxsaldanha.guiadebolsodaenfermagem.domain.Doc
import com.github.barteksc.pdfviewer.listener.OnPageChangeListener
import com.github.barteksc.pdfviewer.listener.OnRenderListener
import kotlinx.android.synthetic.main.activity_pdf.*

/*
    Classe modelo padrão para exibição dos documento em PDF
 */
class ActivityPdf :
        AppCompatActivity(),
        OnPageChangeListener,
        OnRenderListener {

    var doc: Doc? = null
    var toolbar: Toolbar? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pdf)

        //seta a cor Windows StatusBar
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.statusBarColor = Color.rgb(64, 174, 203)
        }

        //ToolBar não default
        toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)

        //Configurações da Toolbar
        supportActionBar?.setHomeButtonEnabled(true) // Habilita botão de voltar
        supportActionBar?.setDisplayHomeAsUpEnabled(true) // Torna o iconce visível
        supportActionBar?.setDisplayShowHomeEnabled(true) // Torna o botão visível

        doc = intent.getParcelableExtra(Doc.DOC_KEY)

        pdfView
                .fromAsset(doc?.path)
                //.defaultPage(doc?.getActualPage(this) ?: 0)
                //.scrollHandle( DefaultScrollHandle(this) )
                .enableSwipe(true)
                .swipeHorizontal(false)
                .password(null)
                .enableDoubletap(true)
                .enableAnnotationRendering(true)
                .enableAntialiasing(true)
                .onPageChange(this)
                .onRender(this)
                .spacing(0)
                .load()

    }

    override fun onResume() {
        super.onResume()
        toolbar?.title = doc?.language
    }

    //Botão de voltar no ToolBar, retorna a home anterior a activity
    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        return when (item!!.itemId) {
            android.R.id.home -> {
                finish()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onPageChanged(page: Int, pageCount: Int) {

    }

    override fun onInitiallyRendered(nbPages: Int) {

    }
}