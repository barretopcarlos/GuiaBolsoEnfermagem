package com.example.maxsaldanha.guiadebolsodaenfermagem.data

import android.content.Context
import com.example.maxsaldanha.guiadebolsodaenfermagem.R
import com.example.maxsaldanha.guiadebolsodaenfermagem.domain.Doc

class Databaseesqueletico {
    companion object{
        fun getDocs() = listOf(
                Doc("", R.drawable.manuaistecnicos, "SISTEMA ESQUELÉTICO"),
                Doc("esqueleticoclavicula.pdf", R.drawable.manuaistecnicos, "CLAVÍCULA"),
                Doc("", R.drawable.manuaistecnicos, "CÓCCIX"),
                Doc("", R.drawable.manuaistecnicos, "COLUNA VERTEBRAL"),
                Doc("", R.drawable.manuaistecnicos, "CONCHA NASAL INFERIOR"),
                Doc("esqueleticocostelas.pdf", R.drawable.manuaistecnicos, "COSTELAS"),
                Doc("", R.drawable.manuaistecnicos, "CRÂNIO COMO UM TODO"),
                Doc("esqueleticoescapula.pdf", R.drawable.manuaistecnicos, "ESCÁPULA"),
                Doc("esqueleticoesfenoide.pdf", R.drawable.manuaistecnicos, "ESFENOIDE"),
                Doc("esqueleticoesterno.pdf", R.drawable.manuaistecnicos, "ESTERNO"),
                Doc("esqueleticoetmoide.pdf", R.drawable.manuaistecnicos, "ETMOIDE"),
                Doc("", R.drawable.manuaistecnicos, "FÊMUR"),
                Doc("", R.drawable.manuaistecnicos, "FÍBULA"),
                Doc("esqueleticofrontal.pdf", R.drawable.manuaistecnicos, "FRONTAL"),
                Doc("esqueleticoiliaco.pdf", R.drawable.manuaistecnicos, "ILÍACO"),
                Doc("esqueleticolacrimal.pdf", R.drawable.manuaistecnicos, "LACRIMAL"),
                Doc("esqueleticomandibula.pdf", R.drawable.manuaistecnicos, "MANDÍBULA"),
                Doc("esqueleticomaxila.pdf", R.drawable.manuaistecnicos, "MAXILAR"),
                Doc("esqueleticonasal.pdf", R.drawable.manuaistecnicos, "NASAL"),
                Doc("esqueleticooccipital.pdf", R.drawable.manuaistecnicos, "OCCIPITAL"),
                Doc("ossosdamao.pdf", R.drawable.manuaistecnicos, "OSSOS DA MÃO"),
                Doc("ossosdope.pdf", R.drawable.manuaistecnicos, "OSSOS DO PÉ"),
                Doc("esqueleticopalatino.pdf", R.drawable.manuaistecnicos, "PALATINO"),
                Doc("", R.drawable.manuaistecnicos, "PARIETAL"),
                Doc("", R.drawable.manuaistecnicos, "PATELA"),
                Doc("", R.drawable.manuaistecnicos, "RÁDIO"),
                Doc("esqueleticosacro.pdf", R.drawable.manuaistecnicos, "SACRA"),
                Doc("esqueleticotemporal.pdf", R.drawable.manuaistecnicos, "TEMPORAL"),
                Doc("", R.drawable.manuaistecnicos, "TÍBIA"),
                Doc("", R.drawable.manuaistecnicos, "ULNA"),
                Doc("esqueleticoumero.pdf", R.drawable.manuaistecnicos, "UMERO"),
                Doc("esqueleticovomer.pdf", R.drawable.manuaistecnicos, "VÔMER"),
                Doc("esqueleticozigomotico.pdf", R.drawable.manuaistecnicos, "ZIGOMÁTICO")
        )

        fun saveActualPageSP(context: Context, key: String, page: Int ){
            context
                    .getSharedPreferences("PREF", Context.MODE_PRIVATE)
                    .edit()
                    .putInt("$key-page", page)
                    .apply()
        }

        fun getActualPageSP(context: Context, key: String )
                = context
                .getSharedPreferences("PREF", Context.MODE_PRIVATE)
                .getInt("$key-page", 0)

    }
}
