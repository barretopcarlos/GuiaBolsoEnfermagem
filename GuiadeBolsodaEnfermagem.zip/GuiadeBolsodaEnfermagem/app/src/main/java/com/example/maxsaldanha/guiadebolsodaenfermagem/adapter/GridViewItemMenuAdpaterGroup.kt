package com.example.maxsaldanha.guiadebolsodaenfermagem.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import com.example.maxsaldanha.guiadebolsodaenfermagem.R
import com.example.maxsaldanha.guiadebolsodaenfermagem.domain.ItemMenuGrid
import kotlinx.android.synthetic.main.item_menu_group_2col.view.*

/* Informe:
    Classe de adapatação do modelo de item exibido no GridView, gerenciando como tamanho, posição no
    array, inflando o layout de XML com o molde a ser exibido.
 */
class GridViewItemMenuAdpaterGroup(context:
                                   Context,//Array com base na classe parâmetro
                                   var itemList: ArrayList<ItemMenuGrid>) : BaseAdapter() {

    var context: Context? = context

    override fun getCount(): Int {
        return itemList.size
    }

    override fun getItem(position: Int): Any {
        return itemList[position]
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val item = this.itemList[position]

        val inflator = context!!.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val itemView = inflator.inflate(R.layout.item_menu_group_2col, null)
        itemView.img_menu.setImageResource(item.imagem!!)
        itemView.tv_name.text = item.nome!!
        return itemView
    }
}

