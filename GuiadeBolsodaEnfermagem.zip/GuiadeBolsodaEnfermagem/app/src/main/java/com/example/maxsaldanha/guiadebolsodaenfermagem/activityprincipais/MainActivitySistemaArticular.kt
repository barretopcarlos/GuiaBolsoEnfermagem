package com.example.maxsaldanha.guiadebolsodaenfermagem.activityprincipais

import android.graphics.Color
import android.os.Build
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.appcompat.widget.Toolbar
import android.view.MenuItem
import com.example.maxsaldanha.guiadebolsodaenfermagem.R
import com.example.maxsaldanha.guiadebolsodaenfermagem.adapter.RecyclerViewDocAdapter
import com.example.maxsaldanha.guiadebolsodaenfermagem.data.Databasearticular
import kotlinx.android.synthetic.main.main_activity_doc.*
class MainActivitySistemaArticular:
        AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.main_activity_doc)

        //seta a cor Windows StatusBar
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.statusBarColor = Color.rgb(64, 174, 203)
        }

        //ToolBar não default
        val toolbar: Toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)

        //Configurações da Toolbar
        supportActionBar!!.title = "SISTEMA ARTICULAR"
        supportActionBar!!.setHomeButtonEnabled(true) // Habilita botão de voltar
        supportActionBar!!.setDisplayHomeAsUpEnabled(true) // Torna o iconce visível
        supportActionBar!!.setDisplayShowHomeEnabled(true) // Torna o botão visível

        initRecycler()
    }

    override fun onResume() {
        super.onResume()
        initRecycler()
    }

    private fun initRecycler() {
        rv_doc.setHasFixedSize(true)

        val mLayoutManager = LinearLayoutManager(this)
        rv_doc.layoutManager = mLayoutManager

        val divider = DividerItemDecoration(this, mLayoutManager.orientation)
        rv_doc.addItemDecoration(divider)

        val adapter = RecyclerViewDocAdapter(this, Databasearticular.getDocs())
        rv_doc.adapter = adapter
    }

    //Botão de voltar no ToolBar, retorna a home anterior a activity
    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        val id = item!!.itemId
        return when (id) {
            android.R.id.home -> {
                finish()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}