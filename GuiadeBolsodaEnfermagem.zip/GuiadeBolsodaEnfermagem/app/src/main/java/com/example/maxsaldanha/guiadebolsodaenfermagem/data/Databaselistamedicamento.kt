package com.example.maxsaldanha.guiadebolsodaenfermagem.data

import android.content.Context
import com.example.maxsaldanha.guiadebolsodaenfermagem.R
import com.example.maxsaldanha.guiadebolsodaenfermagem.domain.Doc

class Databaselistamedicamento{

companion object{
    fun getDocs() = listOf(

            Doc("medacetilcisteina.pdf", R.drawable.medicamentos, "Acetilcisteína"),
            Doc("medaciclovir.pdf", R.drawable.medicamentos, "Aciclovir"),
            Doc("medacidoascorbico.pdf", R.drawable.medicamentos, "Ácido Ascórbico"),
            Doc("medacidotranexanico.pdf", R.drawable.medicamentos, "Ácido Tranexânico")
    )
    fun saveActualPageSP(context: Context, key: String, page: Int ){
        context
                .getSharedPreferences("PREF", Context.MODE_PRIVATE)
                .edit()
                .putInt("$key-page", page)
                .apply()
    }

    fun getActualPageSP(context: Context, key: String )
            = context
            .getSharedPreferences("PREF", Context.MODE_PRIVATE)
            .getInt("$key-page", 0)
}
}