package com.example.maxsaldanha.guiadebolsodaenfermagem.activityprincipais

import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import android.view.MenuItem
import android.widget.AdapterView
import android.widget.GridView
import com.example.maxsaldanha.guiadebolsodaenfermagem.R
import com.example.maxsaldanha.guiadebolsodaenfermagem.adapter.GridViewItemMenuAdpaterGroupMain
import com.example.maxsaldanha.guiadebolsodaenfermagem.domain.ItemMenuGrid

class MainActivityMedicamentoGroup:
        AppCompatActivity(){

    var adapter: GridViewItemMenuAdpaterGroupMain? = null //Adapta o item no GridView
    var itemList = ArrayList<ItemMenuGrid>() //Array com base na classe parâmetro

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.main_activity_medicamento_group)

        //seta a cor Windows StatusBar
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.statusBarColor = Color.rgb(64,174,203)
        }

        //ToolBar não default
        val toolbar: Toolbar =findViewById(R.id.my_toolbar)
        setSupportActionBar(toolbar)

        //Configurações da Toolbar
        supportActionBar!!.title="MEDICAMENTOS"
        supportActionBar!!.setHomeButtonEnabled(true) // Habilita botão de voltar
        supportActionBar!!.setDisplayHomeAsUpEnabled(true) // Torna o iconce visível
        supportActionBar!!.setDisplayShowHomeEnabled(true) // Torna o botão visível

        //Array de preenchimento do GridView
        itemList.add(ItemMenuGrid("LISTA COMPLETA",R.drawable.medicamentos))
        itemList.add(ItemMenuGrid("MEDICAÇÃO NA AMAMENTAÇÃO",R.drawable.amamentacao))
        itemList.add(ItemMenuGrid("UTI NEONATAL",R.drawable.neo))
        itemList.add(ItemMenuGrid("PEDIATRIA",R.drawable.pediatra))

        adapter = GridViewItemMenuAdpaterGroupMain(this,itemList) //Definição da adapter preenchida na classe com items referenciados

        val gridView: GridView =findViewById(R.id.gr_medicamento_activity) //Instância o gridview ao id no xml
        gridView.adapter = adapter //Seta o modelo da adapter no GridView

        //Evento de click na tela
        gridView.onItemClickListener =
                AdapterView.OnItemClickListener { _, _, position, _ ->

                    when(position){
                        0 -> {
                            val i = Intent(this, MainActivityListaMedicamento::class.java)
                            startActivity(i)
                        }
                        1 -> {
                            val i = Intent(this, MainActivityMedicamentosAmamentacao::class.java)
                            startActivity(i)
                        }
                        2 -> {
                            val i = Intent(this, MainActivityDilUtiNeonalta::class.java)
                            startActivity(i)
                        }
                        3 -> {
                            val i = Intent(this, MainActivityDilPediatria::class.java)
                            startActivity(i)
                        }
                    }
                }
    }

    //Botão de voltar no ToolBar, retorna a home anterior a activity
    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        val id = item!!.itemId
        return when (id) {
            android.R.id.home -> {
                finish()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}