package com.example.maxsaldanha.guiadebolsodaenfermagem.activityprincipais

import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import android.view.MenuItem
import android.widget.AdapterView
import android.widget.GridView
import com.example.maxsaldanha.guiadebolsodaenfermagem.R
import com.example.maxsaldanha.guiadebolsodaenfermagem.adapter.GridViewItemMenuAdpaterGroup
import com.example.maxsaldanha.guiadebolsodaenfermagem.domain.ItemMenuGrid

class MainActivityAntomiaGroup :
        AppCompatActivity() {

    var adapter: GridViewItemMenuAdpaterGroup? = null //Adapta o item no GridView
    var itemList = ArrayList<ItemMenuGrid>() //Array com base na classe parâmetro

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.main_activity_anatomia_group)

        //seta a cor Windows StatusBar
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.statusBarColor = Color.rgb(64,174,203)
        }

        //ToolBar não default
        val toolbar: Toolbar =findViewById(R.id.my_toolbar)
        setSupportActionBar(toolbar)

        //Configurações da Toolbar
        supportActionBar!!.title="ANATOMIA HUMANA"
        supportActionBar!!.setHomeButtonEnabled(true)
        supportActionBar!!.setDisplayHomeAsUpEnabled(true)
        supportActionBar!!.setDisplayShowHomeEnabled(true)

        //Array de preenchimento do GridView
        itemList.add(ItemMenuGrid("ARTICULAR", R.drawable.insulina))
        itemList.add(ItemMenuGrid("CARDIOVASCULAR", R.drawable.gotejamento))
        itemList.add(ItemMenuGrid("DIGESTÓRIO", R.drawable.imc))
        itemList.add(ItemMenuGrid("ENDÓCRINO", R.drawable.parto))
        itemList.add(ItemMenuGrid("ESQUELÉTICO", R.drawable.dose))
        itemList.add(ItemMenuGrid("GENITAL ", R.drawable.idade))
        itemList.add(ItemMenuGrid("LINFÁTICO", R.drawable.idade_gest))
        itemList.add(ItemMenuGrid("MUSCULAR", R.drawable.area))
        itemList.add(ItemMenuGrid("NERVOSO", R.drawable.volemica))
        itemList.add(ItemMenuGrid("RESPIRATÓRIO", R.drawable.apgar))
        itemList.add(ItemMenuGrid("TEGUMENTAR", R.drawable.gasglow))
        itemList.add(ItemMenuGrid("URINÁRIO", R.drawable.rass))

        adapter = GridViewItemMenuAdpaterGroup(this,itemList) //Definição da adapter preenchida na classe com items referenciados

        val gridView: GridView =findViewById(R.id.gr_calculos) //Instância o gridview ao id no xml
        gridView.adapter = adapter //Seta o modelo da adapter no GridView

        //Evento de click na tela
        gridView.onItemClickListener =
                AdapterView.OnItemClickListener { _, _, position, _ ->

                    when(position){
                        0 -> {
                            val i = Intent(this, MainActivitySistemaArticular::class.java)
                            startActivity(i)
                        }
                        1 -> {
                            val i = Intent(this, MainActivitySistemaCardiovascular::class.java)
                            startActivity(i)
                        }
                        2 -> {
                            val i = Intent(this, MainActivitySistemaDigetorio::class.java)
                            startActivity(i)
                        }
                        3 -> {
                            val i = Intent(this, MainActivitySistemaEndocrino::class.java )
                            startActivity(i)
                        }
                        4 -> {
                            val i = Intent(this, MainActivitySistemaEsqueletico::class.java)
                            startActivity(i)
                        }
                        5 -> {
                            val i = Intent(this, MainActivitySistemaGenital::class.java)
                            startActivity(i)
                        }
                        6 -> {
                            val i = Intent(this, MainActivitySistemaLinfatico::class.java)
                            startActivity(i)
                        }
                        7 -> {
                            val i = Intent(this, MainActivitySistemaMuscular::class.java )
                            startActivity(i)
                        }
                        8 -> {
                            val i = Intent(this, MainActivitySistemaNervoso::class.java )
                            startActivity(i)
                        }
                        9 -> {
                            val i = Intent(this, MainActivitySistemaRespiratorio::class.java)
                            startActivity(i)
                        }
                        10 -> {
                            val i = Intent(this, MainActivitySistemaTegumentar::class.java)
                            startActivity(i)
                        }
                        11 -> {
                            val i = Intent(this, MainActivitySistemaUrinario::class.java)
                            startActivity(i)
                        }

                    }
                }
    }

    //Botão de voltar no ToolBar, retorna a home anterior a activity
    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        val id = item!!.itemId
        return when (id) {
            android.R.id.home -> {
                finish()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}


