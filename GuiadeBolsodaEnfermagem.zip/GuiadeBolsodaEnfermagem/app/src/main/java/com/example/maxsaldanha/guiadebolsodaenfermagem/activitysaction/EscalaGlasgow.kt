package com.example.maxsaldanha.guiadebolsodaenfermagem.activitysaction

import android.graphics.Color
import android.os.Build
import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import android.view.MenuItem
import android.widget.Button
import android.widget.RadioGroup
import com.example.maxsaldanha.guiadebolsodaenfermagem.Calculos
import com.example.maxsaldanha.guiadebolsodaenfermagem.R

/* Informativo

Referência: http://bvsms.saude.gov.br/bvs/publicacoes/protocolo_acolhimento_classificacao_risco.pdf
 */

class EscalaGlasgow:
        AppCompatActivity(),
        Calculos {
    //Variáveis dos índices da escala de Glasgow
    private var aberturaOcular = 4
    private var respostaVerbal = 5
    private var respostaMotora = 6

    //Variáveis globais, componentes do XML
    private lateinit var radioGroupOcular: RadioGroup
    private lateinit var radioGroupVerbal: RadioGroup
    private lateinit var radioGroupMotora: RadioGroup
    private lateinit var btglasgow: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_escala_glasgow)

        //seta a cor Windows StatusBar
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.statusBarColor = Color.rgb(64,174,203)
        }

        //ToolBar não default
        val toolbar:Toolbar=findViewById(R.id.my_toolbar)
        setSupportActionBar(toolbar)

        //Configurações da Toolbar
        supportActionBar!!.title="ESCALA DE GLASGOW"
        supportActionBar!!.setHomeButtonEnabled(true) // Habilita botão de voltar
        supportActionBar!!.setDisplayHomeAsUpEnabled(true) // Torna o iconce visível
        supportActionBar!!.setDisplayShowHomeEnabled(true) // Torna o botão visível

        //Captura o dado informado no XML
        radioGroupOcular = findViewById(R.id.rg_abertura_ocular)
        radioGroupVerbal = findViewById(R.id.rg_resposta_verbal)
        radioGroupMotora = findViewById(R.id.rg_resposta_motora)
        btglasgow = findViewById(R.id.bt_glasgow)

        try {
            //Evento para calcular o indice de Glasgow, segundo os sinais selecionados nos RadioGroups
            radioGroupOcular.setOnCheckedChangeListener { _, checkedId ->

                when(checkedId){

                    R.id.rb_espontaneo -> {
                        aberturaOcular = 4
                    }
                    R.id.rb_estimulo_verbal -> {
                        aberturaOcular = 3
                    }
                    R.id.rb_estimulo_doloroso -> {
                        aberturaOcular = 2
                    }
                    R.id.rb_abertura_nenhuma -> {
                        aberturaOcular = 1
                    }
                }
            }
            radioGroupVerbal.setOnCheckedChangeListener { _, checkedId ->

                when(checkedId){

                    R.id.rb_orientada -> {
                        respostaVerbal = 5
                    }
                    R.id.rb_confusa -> {
                        respostaVerbal = 4
                    }
                    R.id.rb_inapropriadas -> {
                        respostaVerbal = 3
                    }
                    R.id.rb_incompreensiveis -> {
                        respostaVerbal = 2
                    }
                    R.id.rb_verbal_nenhuma -> {
                        respostaVerbal = 1
                    }
                }
            }
            radioGroupMotora.setOnCheckedChangeListener { _, checkedId ->

                when(checkedId){

                    R.id.rb_obedece_comandos -> {
                        respostaMotora = 6
                    }
                    R.id.rb_localiza_dor -> {
                        respostaMotora = 5
                    }
                    R.id.rb_movimento_retirada -> {
                        respostaMotora = 4
                    }
                    R.id.rb_decorticacao -> {
                        respostaMotora = 3
                    }
                    R.id.rb_descerebracao -> {
                        respostaMotora = 2
                    }
                    R.id.rb_motora_nenhuma -> {
                        respostaMotora = 1
                    }
                }
            }

            btglasgow.setOnClickListener {
                calcular()
            }

        }
        catch (e:Exception){
            e.message
        }
    }
    //Botão de voltar no ToolBar, retorna a home anterior a activity
    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        val id = item!!.itemId
        return when (id) {
            android.R.id.home -> {
                finish()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }

    }

    //Método abstrato, herdado da interface
    override fun calcular() {

        val inglasgow = aberturaOcular + respostaMotora + respostaVerbal

        when {
            inglasgow<9 -> {

                val dialog = AlertDialog.Builder(this, R.style.MyDialogTheme)
                        .setTitle("TRAUMA GRAVE")
                        .setMessage("GLASGOW: $inglasgow")
                        .setNegativeButton("Fechar") { _, _ -> }
                dialog.show()

            }
            (inglasgow>8)&&(inglasgow<13) -> {

                val dialog = AlertDialog.Builder(this, R.style.MyDialogTheme)
                        .setTitle("TRAUMA MODERADO")
                        .setMessage("GLASGOW: $inglasgow")
                        .setNegativeButton("Fechar") { _, _ -> }
                dialog.show()

            }
            else -> {

                val dialog = AlertDialog.Builder(this, R.style.MyDialogTheme)
                        .setTitle("TRAUMA LEVE")
                        .setMessage("GLASGOW: $inglasgow")
                        .setNegativeButton("Fechar") { _, _ -> }
                dialog.show()

            }
        }
    }
}