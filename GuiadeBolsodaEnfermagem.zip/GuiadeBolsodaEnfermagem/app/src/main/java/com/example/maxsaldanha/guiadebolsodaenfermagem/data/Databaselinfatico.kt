package com.example.maxsaldanha.guiadebolsodaenfermagem.data

import android.content.Context
import com.example.maxsaldanha.guiadebolsodaenfermagem.R
import com.example.maxsaldanha.guiadebolsodaenfermagem.domain.Doc

class Databaselinfatico {
    companion object{
        fun getDocs() = listOf(
                Doc("SISTEMA LINFÁTICO.pdf", R.drawable.manuaistecnicos, "SISTEMA LINFÁTICO"),
                Doc("ANATOMIA DO BAÇO.pdf", R.drawable.manuaistecnicos, "ANATOMIA DO BAÇO"),
                Doc("LINFONODOS E VASOS LINFÁTICOS DA PAREDE ABDOMINAL POSTERIOR.pdf", R.drawable.manuaistecnicos, "LINFONODOS E VASOS LINFÁTICOS DA PAREDE ABDOMINAL POSTERIOR"),
                Doc("LINFONODOS SUPERFICIAIS E VASOS LINFÁTICOS DA CABEÇA E DO PESCOÇO.pdf", R.drawable.manuaistecnicos, "LINFONODOS SUPERFICIAIS E VASOS LINFÁTICOS DA CABEÇA E DO PESCOÇO"),
                Doc("VASOS LINFÁTICOS E LINFONODOS DA FARINGE.pdf", R.drawable.manuaistecnicos, "VASOS LINFÁTICOS E LINFONODOS DA FARINGE"),
                Doc("VASOS LINFÁTICOS E LINFONODOS DA GLÂNDULA MAMÁRIA.pdf", R.drawable.manuaistecnicos, "VASOS LINFÁTICOS E LINFONODOS DA GLÂNDULA MAMÁRIA"),
                Doc("VASOS LINFÁTICOS E LINFONODOS DA REGIÃO POPLÍTEA.pdf", R.drawable.manuaistecnicos, "VASOS LINFÁTICOS E LINFONODOS DA REGIÃO POPLÍTEA"),
                Doc("VASOS LINFÁTICOS E LINFONODOS DO MEMBRO INFERIOR.pdf", R.drawable.manuaistecnicos, "VASOS LINFÁTICOS E LINFONODOS DO MEMBRO INFERIOR"),
                Doc("VASOS LINFÁTICOS E LINFONODOS DO MEMBRO SUPERIOR.pdf", R.drawable.manuaistecnicos, "VASOS LINFÁTICOS E LINFONODOS DO MEMBRO SUPERIOR"),
                Doc("VASOS LINFÁTICOS E LINFONODOS DO PERÍNEO E REGIÃO INGUINAL.pdf", R.drawable.manuaistecnicos, "VASOS LINFÁTICOS E LINFONODOS DO PERÍNEO E REGIÃO INGUINAL")

        )fun saveActualPageSP(context: Context, key: String, page: Int ){
            context
                    .getSharedPreferences("PREF", Context.MODE_PRIVATE)
                    .edit()
                    .putInt("$key-page", page)
                    .apply()
        }

        fun getActualPageSP(context: Context, key: String )
                = context
                .getSharedPreferences("PREF", Context.MODE_PRIVATE)
                .getInt("$key-page", 0)

    }
}
