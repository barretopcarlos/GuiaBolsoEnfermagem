package com.example.maxsaldanha.guiadebolsodaenfermagem.domain

/*
    Classe de domínio para os itens inseridos no recylerview dos item das listas
 */
class ItemMenuLista(titulo: String, texto: String) {

    var titulo:String? = titulo
    var texto:String? = texto

}