package com.example.maxsaldanha.guiadebolsodaenfermagem.activitysaction

import android.graphics.Color
import android.os.Build
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import android.view.MenuItem
import android.view.View
import android.widget.EditText
import com.example.maxsaldanha.guiadebolsodaenfermagem.Calculos
import com.example.maxsaldanha.guiadebolsodaenfermagem.R

/*Informe:

Método para Cálculo da Data Provável do Parto (DPP) Calcula-se a data provável do parto levando-se
em consideração a duração média da gestação normal (280 dias ou 40 semanas a partir da DUM), mediante
a utilização de um calendário ou gestograma. Uma outra forma de cálculo é somar sete dias ao primeiro
dia da última menstruação e adicionar nove meses ao mês em que ocorreu a última menstruação.
    Exemplos:
    Data da última menstruação: 13/9/95
    Data provável do parto: 20/6/96
   Referência:
http://bvsms.saude.gov.br/bvs/publicacoes/cd04_11.pdf

 */
class DataProvavelParto:
        AppCompatActivity(),
        Calculos {

    //Variável para conversão de ano e mês.
    private val ano:Double = 365.25
    private val mes:Double = 30.416666667

    //Variáveis, componentes do XML
    private lateinit var diaDum:EditText
    private lateinit var mesDum:EditText
    private lateinit var anoDum:EditText
    private lateinit var resultadoDPP:EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_data_provavel_parto)

        //seta a cor Windows StatusBar
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.statusBarColor = Color.rgb(64,174,203)
        }

        //ToolBar não default
        val toolbar:Toolbar=findViewById(R.id.my_toolbar)
        setSupportActionBar(toolbar)

        //Configurações da Toolbar
        supportActionBar!!.title = "DATA PROVÁVEL PARTO"
        supportActionBar!!.setHomeButtonEnabled(true) // Habilita botão de voltar
        supportActionBar!!.setDisplayHomeAsUpEnabled(true) // Torna o iconce visível
        supportActionBar!!.setDisplayShowHomeEnabled(true) // Torna o botão acessível

        //Captura o dado informado no XML
        diaDum = findViewById(R.id.et_dia_dpp)
        mesDum = findViewById(R.id.et_mes_dpp)
        anoDum = findViewById(R.id.et_ano_dpp)
        resultadoDPP = findViewById(R.id.et_result_dpp)

        //Método focus para capturar o dado inserido após a confirmação, sem botão de ação.
        diaDum.onFocusChangeListener = View.OnFocusChangeListener { _, _ ->
            calcular()
        }
        mesDum.onFocusChangeListener = View.OnFocusChangeListener { _, _ ->
            calcular()
        }
        anoDum.onFocusChangeListener = View.OnFocusChangeListener { _, _ ->
            calcular()
        }
    }

    //Botão de voltar no ToolBar, retorna a home anterior a activity
    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        val id = item!!.itemId
        return when (id) {
            android.R.id.home -> {
                finish()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
    //Método abstrato, herdado da interface
    override fun calcular() {

        try {

            var diaDpp:Int = Integer.parseInt(diaDum.text.toString())//Captura dia informado pelo usuário
            var mesDpp:Int = Integer.parseInt(mesDum.text.toString()) //Captura mês informado pelo usuário
            val anoDpp:Int = Integer.parseInt(anoDum.text.toString()) //Captura ano informado pelo usuário

            //Condição de teste para quanto a data e mês com valor absurdo
            when {
                (mesDpp == 1 || mesDpp == 3 ||  mesDpp == 5 || mesDpp == 7 || mesDpp == 8 ||
                        mesDpp == 10 || mesDpp ==12) && diaDpp > 31 -> resultadoDPP.setText("Dia maior do que 31")
                (mesDpp == 4 || mesDpp == 6 || mesDpp == 9 || mesDpp == 11) && diaDpp > 30 -> resultadoDPP.setText("Dia maior do que 30")
                mesDpp == 2 && anoDpp%4 == 0 && diaDpp > 29 -> resultadoDPP.setText("Dia maior do que 29")
                mesDpp == 2 && anoDpp%4 != 0 && diaDpp > 28 -> resultadoDPP.setText("Dia maior do que 28")
                mesDpp > 12 -> resultadoDPP.setText("Mês maior do que 12")
                else -> {

                    diaDpp += 7
                    mesDpp += 9

                    //Converte em dias a data de hoje e data de nascimento
                    val hojenasc: Double = diaDpp + (mesDpp * mes) + (anoDpp * ano)

                    //Converte a diferença em dias para anos, meses e dias
                    var anos: Double = hojenasc / ano
                    var meses: Double = (hojenasc % ano) / mes
                    val diass: Double = (hojenasc % ano) % mes

                    when {
                        meses < 1 -> {
                            //Ajuste de data corrigindo o mês que ao chegar a 12 converte para mais 1 ano e 0 mes
                            meses += 12
                            anos -= 1

                            resultadoDPP.setText("""DPP: ${diass.toInt()}/${meses.toInt()}/${anos.toInt()}""")
                        }
                        else -> resultadoDPP.setText("""DPP: ${diass.toInt()}/${meses.toInt()}/${anos.toInt()}""")
                    }
                }
            }
        }
        catch (e:Exception){
            e.message
        }
    }

}

