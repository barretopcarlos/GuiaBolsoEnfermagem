package com.example.maxsaldanha.guiadebolsodaenfermagem.data

import android.content.Context
import com.example.maxsaldanha.guiadebolsodaenfermagem.R
import com.example.maxsaldanha.guiadebolsodaenfermagem.domain.Doc

class Databasenervoso {
    companion object{
        fun getDocs() = listOf(
                Doc("SISTEMA NERVOSO.pdf", R.drawable.manuaistecnicos, "SISTEMA NERVOSO"),
                Doc("CEREBELO.pdf", R.drawable.manuaistecnicos, "CEREBELO"),
                Doc("DIENCÉFALO.pdf", R.drawable.manuaistecnicos, "DIENCÉFALO"),
                Doc("MANÍNGES E LÍQUOR.pdf", R.drawable.manuaistecnicos, "MANÍNGES E LÍQUOR"),
                Doc("MANÍNGES E LÍQUOR.pdf", R.drawable.manuaistecnicos, "MANÍNGES E LÍQUOR"),
                Doc("NERVOS CRANIANOS.pdf", R.drawable.manuaistecnicos, "NERVOS CRANIANOS"),
                Doc("NERVOS ESPINHAIS.pdf", R.drawable.manuaistecnicos, "NERVOS ESPINHAIS"),
                Doc("NERVOS TORÁCICOS.pdf", R.drawable.manuaistecnicos, "NERVOS TORÁCICOS"),
                Doc("PLEXO BRAQUIAL.pdf", R.drawable.manuaistecnicos, "PLEXO BRAQUIAL"),
                Doc("PLEXO CERVICAL.pdf", R.drawable.manuaistecnicos, "PLEXO CERVICAL"),
                Doc("PLEXO COCCIGEO.pdf", R.drawable.manuaistecnicos, "PLEXO COCCIGEO"),
                Doc("PLEXO LOMBAR.pdf", R.drawable.manuaistecnicos, "PLEXO LOMBAR"),
                Doc("PLEXO SACRAL.pdf", R.drawable.manuaistecnicos, "PLEXO SACRAL"),
                Doc("TECIDO NERVOSO.pdf", R.drawable.manuaistecnicos, "TECIDO NERVOSO"),
                Doc("TELENCÉFALO.pdf", R.drawable.manuaistecnicos, "TELENCÉFALO"),
                Doc("TRONCO ENCEFÁLICO.pdf", R.drawable.manuaistecnicos, "TRONCO ENCEFÁLICO"),
                Doc("VASCULARIZAÇÃO.pdf", R.drawable.manuaistecnicos, "VASCULARIZAÇÃO")
        )fun saveActualPageSP(context: Context, key: String, page: Int ){
            context
                    .getSharedPreferences("PREF", Context.MODE_PRIVATE)
                    .edit()
                    .putInt("$key-page", page)
                    .apply()
        }

        fun getActualPageSP(context: Context, key: String )
                = context
                .getSharedPreferences("PREF", Context.MODE_PRIVATE)
                .getInt("$key-page", 0)

    }
}
