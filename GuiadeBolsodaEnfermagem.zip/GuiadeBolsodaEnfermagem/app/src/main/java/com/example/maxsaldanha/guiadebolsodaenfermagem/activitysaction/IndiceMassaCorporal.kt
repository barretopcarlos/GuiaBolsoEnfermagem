package com.example.maxsaldanha.guiadebolsodaenfermagem.activitysaction

import android.graphics.Color
import android.os.Build
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import android.view.MenuItem
import android.view.View
import android.widget.EditText
import com.example.maxsaldanha.guiadebolsodaenfermagem.Calculos
import com.example.maxsaldanha.guiadebolsodaenfermagem.R
import java.lang.Double.parseDouble
import java.text.DecimalFormat

/* Infotmativo
    Avaliação do peso em adultos (20 a 59 anos)
Os parâmetros indicados pelo Ministério da Saúde para avaliação do estado nutricional de pessoas
entre 20 e 59 anos são o Índice de Massa Corporal (IndiceMassaCorporal) e o perímetro da cintura ou circunferência
da cintura. O resultado do cálculo do IndiceMassaCorporal deve ser analisado de acordo com a classificação definida
pela Organização Mundial de Saúde (OMS), válida somente para pessoas adultas:
Baixo peso: < 18,5 | Peso adequado: ≥ 18,5 e < 25 | Sobrepeso: ≥ 25 e < 30 | Obesidade: ≥ 30

Fonte: http://portalms.saude.gov.br/component/content/article/804-imc/40509-imc-em-adultos
     */

class IndiceMassaCorporal: AppCompatActivity(),
        Calculos {

    private var imc:Double =0.0

    //Variáveis, componentes do XML
    private lateinit var peso:EditText
    private lateinit var altura:EditText
    private lateinit var resulIMC:EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_massa_corporal)

        //seta a cor Windows StatusBar
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.statusBarColor = Color.rgb(64,174,203)
        }

        //ToolBar não default
        val toolbar: Toolbar =findViewById(R.id.my_toolbar)
        setSupportActionBar(toolbar)

        //Configurações da Toolbar
        supportActionBar!!.title="IMC"
        supportActionBar!!.setHomeButtonEnabled(true) // Habilita botão de voltar
        supportActionBar!!.setDisplayHomeAsUpEnabled(true) // Torna o iconce visível
        supportActionBar!!.setDisplayShowHomeEnabled(true) // Torna o botão visível

        //Captura o dado informado no XML
        peso=findViewById(R.id.imcpeso)
        altura=findViewById(R.id.imcaltura)
        resulIMC=findViewById(R.id.resulIMC)

        //Método focus para capturar o dado inserido após a confirmação, sem botão de ação.
        peso.onFocusChangeListener = View.OnFocusChangeListener { _, _ ->
            calcular()
        }
        altura.onFocusChangeListener = View.OnFocusChangeListener { _, _ ->
            calcular()
        }
    }

    //Botão de voltar no ToolBar, retorna a home anterior a activity
    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        val id = item!!.itemId
        return when (id) {
            android.R.id.home -> {
                finish()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
    //Método abstrato, herdado da interface
    override fun calcular(){

        try {
            //Conversão de tipo de variável
            val peso:Double= parseDouble(peso.text.toString())
            val altura:Double= parseDouble(altura.text.toString())


            when {
                altura>2.15 -> //Fórmula
                    imc = peso/((altura*altura)/10000)
                else -> //Fórmula
                    imc = peso/(altura*altura)
            }

            //Variável cria molde para o números de casas decimais após o ponto.
            val decimalFormat= DecimalFormat(".#")

            when {
                peso>500 || peso<35 -> resulIMC.setText("Verifique o peso digitado.")
                imc < 18.5 -> //Resultado setado num EditText
                    resulIMC.setText("IMC: "+decimalFormat.format(imc).toString() + " | Baixo Peso")
                imc >= 18.5 && imc < 25 -> //Resultado setado num EditText
                    resulIMC.setText("IMC: "+decimalFormat.format(imc).toString() + " | Peso adequado")
                imc >=25 && imc < 30 -> //Resultado setado num EditText
                    resulIMC.setText("IMC: "+decimalFormat.format(imc).toString() + " | Sobrepeso")
                imc>= 30 -> //Resultado setado num EditText
                    resulIMC.setText("IMC: "+decimalFormat.format(imc).toString() + " | Obesidade")
            }

        }
        catch (e : Exception){
            e.message
        }
    }
}