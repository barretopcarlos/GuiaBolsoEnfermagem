package com.example.maxsaldanha.guiadebolsodaenfermagem.domain

/*
    Classe de domínio para os itens inseridos no gridview dos menus
 */
class ItemMenuGrid(nome: String, imagem: Int) {

    var nome:String? = nome
    var imagem:Int? = imagem

}