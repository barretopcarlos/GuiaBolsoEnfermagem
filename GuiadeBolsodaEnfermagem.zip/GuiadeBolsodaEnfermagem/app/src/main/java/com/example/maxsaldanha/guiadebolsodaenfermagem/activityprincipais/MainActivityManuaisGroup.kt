package com.example.maxsaldanha.guiadebolsodaenfermagem.activityprincipais

import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import android.view.MenuItem
import android.widget.AdapterView
import android.widget.GridView
import com.example.maxsaldanha.guiadebolsodaenfermagem.R
import com.example.maxsaldanha.guiadebolsodaenfermagem.adapter.GridViewItemMenuAdpaterGroupMain
import com.example.maxsaldanha.guiadebolsodaenfermagem.domain.ItemMenuGrid

class MainActivityManuaisGroup:
        AppCompatActivity(){

    var adapter: GridViewItemMenuAdpaterGroupMain? = null //Adapta o item no GridView
    var itemList = ArrayList<ItemMenuGrid>() //Array com base na classe parâmetro

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.main_activity_manuais_group)

        //seta a cor Windows StatusBar
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.statusBarColor = Color.rgb(64,174,203)
        }

        //ToolBar não default
        val toolbar:Toolbar=findViewById(R.id.my_toolbar)
        setSupportActionBar(toolbar)

        //Configurações da Toolbar
        supportActionBar!!.setHomeButtonEnabled(true)
        supportActionBar!!.setDisplayHomeAsUpEnabled(true)
        supportActionBar!!.title="MANUAIS"
        supportActionBar!!.setDisplayShowHomeEnabled(true)

        //Array de preenchimento do GridView
        itemList.add(ItemMenuGrid("ANATOMIA", R.drawable.anatomia))
        itemList.add(ItemMenuGrid("MEDICAMENTOS", R.drawable.medicamentos))
        itemList.add(ItemMenuGrid("PROCEDIMENTOS", R.drawable.procedimentos))
        itemList.add(ItemMenuGrid("TERMOS TÉCNICOS",R.drawable.termos))
        itemList.add(ItemMenuGrid("SIGLAS",R.drawable.sigla))
        itemList.add(ItemMenuGrid("MANUAL DO USUÁRIO",R.drawable.usuario))


        adapter = GridViewItemMenuAdpaterGroupMain(this,itemList) //Definição da adapter preenchida na classe com items referenciados


        val gridView: GridView =findViewById(R.id.gr_manuais) //Instância o gridview ao id no xml
        gridView.adapter = adapter //Seta o modelo da adapter no GridView

        //Evento de click na tela
        gridView.onItemClickListener =
            AdapterView.OnItemClickListener { _, _, position, _ ->

                when(position){
                    0 -> {
                        val i = Intent(this, MainActivityAntomiaGroup::class.java)
                        startActivity(i)
                    }
                    1 -> {
                        val i = Intent(this, MainActivityMedicamentoGroup::class.java )
                        startActivity(i)
                    }
                    2 -> {
                        val i = Intent(this, MainActivityProcedimento::class.java)
                        startActivity(i)
                    }
                    3 -> {
                        val i = Intent(this, MainActivityTermos::class.java )
                        startActivity(i)
                    }
                    4 ->{
                        val i = Intent(this, MainActivitySigla::class.java)
                        startActivity(i)
                    }
                    5 -> {
                        val i = Intent(this, MainActivityManualUsuario::class.java)
                        startActivity(i)
                    }

                }
            }

}

    //Botão de voltar no ToolBar, retorna a home anterior a activity
    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        val id = item!!.itemId
        return when (id) {
            android.R.id.home -> {
                finish()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}