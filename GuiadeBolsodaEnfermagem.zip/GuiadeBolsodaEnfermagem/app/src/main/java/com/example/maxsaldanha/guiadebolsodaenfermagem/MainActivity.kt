package com.example.maxsaldanha.guiadebolsodaenfermagem

import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.AdapterView
import android.widget.GridView
import com.example.maxsaldanha.guiadebolsodaenfermagem.activityprincipais.MainActivityAgenda
import com.example.maxsaldanha.guiadebolsodaenfermagem.activityprincipais.MainActivityCalculos
import com.example.maxsaldanha.guiadebolsodaenfermagem.activityprincipais.MainActivityCoren
import com.example.maxsaldanha.guiadebolsodaenfermagem.activityprincipais.MainActivityManuaisGroup
import com.example.maxsaldanha.guiadebolsodaenfermagem.adapter.GridViewItemMenuAdpaterGroupMain
import com.example.maxsaldanha.guiadebolsodaenfermagem.domain.ItemMenuGrid
//TESTE DE COMMIT

/* Classe Principal
    Activity incial, manipula o acesso via Intent para classe Agenda, classe Cálculos, classe Manuais,
    classe Coren.
    Estruturada em um GridView, manipulado pela classe ImageAdapterMain
 */

class MainActivity :
        AppCompatActivity() {

    var adapter: GridViewItemMenuAdpaterGroupMain? = null //Adapta o item no GridView
    var itemList = ArrayList<ItemMenuGrid>() //Array com base na classe parâmetro


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //seta a cor barra de notificação
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.statusBarColor = Color.rgb(64,174,203)
        }
        //Definição da adapter preenchida na classe com items referenciados
        adapter = GridViewItemMenuAdpaterGroupMain(this,itemList)

        itemList.add(ItemMenuGrid("PLANTÕES", R.drawable.agenda))
        itemList.add(ItemMenuGrid("CÁLCULOS", R.drawable.calculos))
        itemList.add(ItemMenuGrid("MANUAIS", R.drawable.manuais))
        itemList.add(ItemMenuGrid("COREN ", R.drawable.coren))

        val gridView: GridView = findViewById(R.id.gr_menu_activity) //Instância o gridview ao id no xml
        gridView.adapter = adapter //Seta o modelo da adapter no GridView

        //Evento de click na tela
        gridView.onItemClickListener =
                AdapterView.OnItemClickListener { _, _, position, _ ->

                    when(position){
                        0 -> {
                            val i = Intent(this, MainActivityAgenda::class.java)
                            startActivity(i)
                        }
                        1 -> {
                            val i = Intent(this, MainActivityCalculos::class.java )
                            startActivity(i)
                        }
                        2 -> {
                            val i = Intent(this, MainActivityManuaisGroup::class.java)
                            startActivity(i)
                        }
                        3 -> {
                            val i = Intent(this, MainActivityCoren::class.java )
                            startActivity(i)
                         }
                    }
                }
    }
}



