package com.example.maxsaldanha.guiadebolsodaenfermagem.domain

import android.os.Parcel
import android.os.Parcelable

/*
    Classe de domínio para documentos
 */
class Doc(
        val path: String?,
        val imageRes: Int,
        val language: String?) : Parcelable {

    /*fun saveActualPage(context: Context, page: Int ){
        Databaseprocedimento.saveActualPageSP(context, path, page)
    }

    fun getActualPage(context: Context, plusPage: Int = 0 )
            = Databaseprocedimento.getActualPageSP(context, path) + plusPage*/

    companion object {
        const val DOC_KEY = "doc"

        @JvmField val CREATOR: Parcelable.Creator<Doc> = object : Parcelable.Creator<Doc> {
            override fun createFromParcel(source: Parcel): Doc = Doc(source)
            override fun newArray(size: Int): Array<Doc?> = arrayOfNulls(size)
        }
    }

    constructor(source: Parcel) : this(
            source.readString(),
            source.readInt(),
            source.readString()
    )

    override fun describeContents() = 0

    override fun writeToParcel(dest: Parcel, flags: Int) {
        dest.writeString(path)
        dest.writeInt(imageRes)
        dest.writeString(language)

    }

}