package com.example.maxsaldanha.guiadebolsodaenfermagem.data

import android.content.Context
import com.example.maxsaldanha.guiadebolsodaenfermagem.R
import com.example.maxsaldanha.guiadebolsodaenfermagem.domain.Doc

class Databasetegumentar {
    companion object{
        fun getDocs() = listOf(
                Doc("SISTEMA TEGUMENTAR.pdf", R.drawable.manuaistecnicos, "SISTEMA TEGUMENTAR"),
                Doc("ANEXOS DA PELE.pdf", R.drawable.manuaistecnicos, "ANEXOS DA PELE"),
                Doc("DERME.pdf", R.drawable.manuaistecnicos, "DERME"),
                Doc("EPIDERME.pdf", R.drawable.manuaistecnicos, "EPIDERME"),
                Doc("TECIDO SUBCUTÂNEO.pdf", R.drawable.manuaistecnicos, "TECIDO SUBCUTÂNEO")

        )fun saveActualPageSP(context: Context, key: String, page: Int ){
            context
                    .getSharedPreferences("PREF", Context.MODE_PRIVATE)
                    .edit()
                    .putInt("$key-page", page)
                    .apply()
        }

        fun getActualPageSP(context: Context, key: String )
                = context
                .getSharedPreferences("PREF", Context.MODE_PRIVATE)
                .getInt("$key-page", 0)

    }
}
