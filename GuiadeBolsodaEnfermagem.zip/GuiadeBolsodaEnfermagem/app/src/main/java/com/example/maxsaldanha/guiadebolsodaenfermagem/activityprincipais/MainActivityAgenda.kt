package com.example.maxsaldanha.guiadebolsodaenfermagem.activityprincipais

import android.graphics.Color
import android.os.Build
import android.os.Bundle
import com.google.android.material.floatingactionbutton.FloatingActionButton
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.appcompat.widget.Toolbar
import android.view.MenuItem
import com.example.maxsaldanha.guiadebolsodaenfermagem.R
import com.example.maxsaldanha.guiadebolsodaenfermagem.activityfragment.PlantaoDialogFragment
import com.example.maxsaldanha.guiadebolsodaenfermagem.adapter.RecyclerViewPlantaoAdapter
import com.example.maxsaldanha.guiadebolsodaenfermagem.domain.Plantao
import com.orhanobut.hawk.Hawk
import kotlinx.android.synthetic.main.main_activity_agenda.*

/* Classe Agenda
    Classe responsável pela armazenamento da agenda de plantões dos profissionais, servindo de
    controle, segundo a regra do negócio, que um profissional pode trabalhar em vários lugares, e
    essa escala pode coincidir, a agenda permite que o mesmo cadastre para nível de controle e
    informativo para anotação da resolução tomada em caso de conflito de escala.
 */

class MainActivityAgenda:
        AppCompatActivity(){

    val list = ArrayList<Plantao>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.main_activity_agenda)

        //seta a cor Windows StatusBar
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.statusBarColor = Color.rgb(64,174,203)
        }

        //ToolBar não default
        val toolbar:Toolbar=findViewById(R.id.my_toolbar)
        setSupportActionBar(toolbar)

        //Floating Button, invoca a classe de cadastro de plantão
        val fab: FloatingActionButton = findViewById(R.id.fab_agenda)
        fab.setOnClickListener {
           initTaskDialog()
        }
        initList()
        initRecycler()

        //Configurações da Toolbar
        supportActionBar!!.title="AGENDA DE PLANTÕES"
        supportActionBar!!.setHomeButtonEnabled(true) // Habilita botão de voltar
        supportActionBar!!.setDisplayHomeAsUpEnabled(true) // Torna o iconce visível
        supportActionBar!!.setDisplayShowHomeEnabled(true) // Torna o botão visível

    }

    //Botão de voltar no ToolBar, retorna a home anterior a activity
    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        val id = item!!.itemId
        return when (id) {
            android.R.id.home -> {
                finish()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun initList(){
        Hawk.init(this).build()

        if( !Hawk.contains( Plantao.TO_DO_LIST_KEY ) ){
            Hawk.put(Plantao.TO_DO_LIST_KEY, list)
        }

        list.addAll( Hawk.get(Plantao.TO_DO_LIST_KEY) )
    }


    private fun initRecycler() {
        rv_todo.setHasFixedSize(true)

        val mLayoutManager = LinearLayoutManager(this)
        rv_todo.layoutManager = mLayoutManager

        val divider = DividerItemDecoration(
                this,
                mLayoutManager.orientation)
        rv_todo.addItemDecoration(divider)

        val adapter = RecyclerViewPlantaoAdapter(this, list)
        rv_todo.adapter = adapter
    }


    private fun initTaskDialog(){
        val fm = supportFragmentManager
        val ft = fm.beginTransaction()
        val fragAnterior = fm.findFragmentByTag(PlantaoDialogFragment.KEY)

        if (fragAnterior != null) {
            ft.remove(fragAnterior)
        }
        ft.addToBackStack(null)

        val dialog = PlantaoDialogFragment()
        dialog.show(ft, PlantaoDialogFragment.KEY)
    }

    fun addToList(plantao: Plantao ){
        list.add( plantao )
        list.sortWith(
                compareBy<Plantao>{ it.getDateInSeconds() }
                        .thenBy{ it.duration }
        )
        Hawk.put( Plantao.TO_DO_LIST_KEY, list )
        rv_todo.adapter!!.notifyItemInserted( list.indexOf( plantao ) )
    }

    fun removeFromList(position: Int ){
        list.removeAt( position )
        Hawk.put( Plantao.TO_DO_LIST_KEY, list )
        rv_todo.adapter!!.notifyItemRemoved( position )
    }

    fun isRecyclerAnimationg() = rv_todo.isAnimating || rv_todo.isComputingLayout

}