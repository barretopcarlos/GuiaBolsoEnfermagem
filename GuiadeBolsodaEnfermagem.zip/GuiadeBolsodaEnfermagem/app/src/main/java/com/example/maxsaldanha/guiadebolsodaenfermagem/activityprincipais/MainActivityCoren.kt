package com.example.maxsaldanha.guiadebolsodaenfermagem.activityprincipais

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import android.view.MenuItem
import android.view.View
import android.webkit.WebView
import android.widget.AdapterView
import android.widget.Spinner
import com.example.maxsaldanha.guiadebolsodaenfermagem.R


/*
    Classe de acesso aos portais de cada conselho regional de enfermagem no território brasileiro
    faz uma fronteira externa, usando recursos dos sites e possibilitando o usuário a acessar sem
    sair da aplicação, a disponibilidade dos sites é de total responsabilidade dos seus respectivos
    conselhor.
 */

class MainActivityCoren:
        AppCompatActivity() {

    //Variáveis globais, componentes do XML
    private lateinit var spinner: Spinner

    @SuppressLint("SetJavaScriptEnabled", "JavascriptInterface")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.main_activity_coren)

        //seta a cor Windows StatusBar
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.statusBarColor = Color.rgb(64,174,203)
        }

        //ToolBar não default
        val toolbar: Toolbar = findViewById(R.id.my_toolbar)
        setSupportActionBar(toolbar)

        //Configurações da Toolbar
        supportActionBar!!.title = "COREN"
        supportActionBar!!.setHomeButtonEnabled(true) // Habilita botão de voltar
        supportActionBar!!.setDisplayHomeAsUpEnabled(true) // Torna o iconce visível
        supportActionBar!!.setDisplayShowHomeEnabled(true) // Torna o botão visível

        //Configurações do evento WebView
        val webview = findViewById<WebView>(R.id.webView)

        webview.settings.javaScriptEnabled = true //Se não ativado, sites podem não funcionar
        webview.settings.allowFileAccessFromFileURLs  = true
        webview.settings.javaScriptCanOpenWindowsAutomatically  = true
        webview.settings.domStorageEnabled  = true
        webview.settings.useWideViewPort  = true
        webview.settings.loadWithOverviewMode = true
        webview.settings.supportZoom()
        webview.settings.builtInZoomControls

        //Configurações do Spinner com a lista dos portais dos conselhos
        spinner=findViewById(R.id.sp_coren)

        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {
                TODO("not implemented") //To change body of created functions use File
                // | Settings | File Templates.
            }
            //Evento de click do Spinner
            override fun onItemSelected(parent: AdapterView<*>, view: View, position: Int, id: Long){

                when (position) {
                    1 -> {//Cofen
                        /* val url ="http://www.cofen.gov.br/"
                        Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                            startActivity(this)
                        }
                        finish()*/
                        webview.loadUrl("http://www.cofen.gov.br/")
                    }
                    2 ->{// Acre
                        /*val url = "http://www.coren-ac.com.br/"
                        Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                            startActivity(this)
                        }
                        finish()*/
                        webview.loadUrl("http://www.coren-ac.com.br/")
                    }
                    3 ->{// Alagoas
                        /*val url = "http://al.corens.portalcofen.gov.br/"
                        Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                            startActivity(this)
                        }
                        finish()*/
                        webview.loadUrl("http://al.corens.portalcofen.gov.br/")
                    }
                    4 ->{// Amapá
                        /*val url = "http://www.coren-ap.gov.br/"
                        Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                            startActivity(this)
                        }
                        finish()*/
                        webview.loadUrl("http://www.coren-ap.gov.br/")
                    }
                    5 ->{// Amazonas
                        /*val url = "http://www.corenam.gov.br/"
                        Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                            startActivity(this)
                        }
                        finish()*/
                        webview.loadUrl("http://www.corenam.gov.br/")
                    }
                    6 ->{// Bahia
                        /*val url = "http://ba.corens.portalcofen.gov.br/"
                        Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                            startActivity(this)
                        }
                        finish()*/
                        webview.loadUrl("http://ba.corens.portalcofen.gov.br/")
                    }
                    7 ->{// Ceará
                        /*val url = "http://ce.corens.portalcofen.gov.br/"
                        Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                            startActivity(this)
                        }
                        finish()*/
                        webview.loadUrl("http://ce.corens.portalcofen.gov.br/")
                    }
                    8 ->{// Distrito Federal
                        /*val url = "http://www.coren-df.gov.br/site/#"
                        Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                            startActivity(this)
                        }
                        finish()*/
                        webview.loadUrl("http://www.coren-df.gov.br/site/#")
                    }
                    9 ->{// Espírito Santo
                        /*val url = "http://www.coren-es.org.br/"
                        Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                            startActivity(this)
                        }
                        finish()*/
                        webview.loadUrl("http://www.coren-es.org.br/")
                    }
                    10 ->{// Goiáis
                        /*val url = "http://www.corengo.org.br/"
                        Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                            startActivity(this)
                        }
                        finish()*/
                        webview.loadUrl("http://www.corengo.org.br/")
                    }
                    11 ->{// Manaus
                        /*val url = "http://www.corenma.gov.br/2015/"
                        Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                            startActivity(this)
                        }
                        finish()*/
                        webview.loadUrl("http://www.corenma.gov.br/2015/")
                    }
                    12 ->{// Mato Grosso
                        /*val url = "http://mt.corens.portalcofen.gov.br/"
                        Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                            startActivity(this)
                        }
                        finish()*/
                        webview.loadUrl("http://mt.corens.portalcofen.gov.br/")
                    }
                    13 ->{// Mato Grosso do Sul
                        /*val url = "http://ms.corens.portalcofen.gov.br/"
                        Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                            startActivity(this)
                        }
                        finish()*/
                        webview.loadUrl("http://ms.corens.portalcofen.gov.br/")
                    }
                    14 ->{// Minas Gerais
                        val url ="https://www.corenmg.gov.br/web/guest"
                        Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                            startActivity(this)
                        }
                        finish()
                        //webview.loadUrl("https://www.corenmg.gov.br/web/guest")
                    }
                    15 ->{// Pará
                        /*val url = "http://pa.corens.portalcofen.gov.br/"
                        Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                            startActivity(this)
                        }
                        finish()*/
                        webview.loadUrl("http://pa.corens.portalcofen.gov.br/")
                    }
                    16 ->{// Paraíba
                        /*val url = "http://www.corenpb.gov.br/"
                        Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                            startActivity(this)
                        }
                        finish()*/
                        webview.loadUrl("http://www.corenpb.gov.br/")
                    }
                    17 ->{// Paraná
                        /*val url = "http://www.corenpr.gov.br/portal/"
                        Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                            startActivity(this)
                        }
                        finish()*/
                        webview.loadUrl("http://www.corenpr.gov.br/portal/")
                    }
                    18 ->{// Pernambuco
                        /*val url = "http://www.coren-pe.gov.br/novo/"
                        Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                            startActivity(this)
                        }
                        finish()*/
                        webview.loadUrl("http://www.coren-pe.gov.br/novo/")
                    }
                    19 ->{// Piuaí
                        /*val url = "http://www.coren-pi.com.br/"
                        Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                            startActivity(this)
                        }
                        finish()*/
                        webview.loadUrl("http://www.coren-pi.com.br/")
                    }
                    20 ->{
                        /*val url = "http://rj.corens.portalcofen.gov.br/"
                        Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                            startActivity(this)
                        }
                        finish()*/
                        webview.loadUrl("http://rj.corens.portalcofen.gov.br/")
                    }
                    21 ->{
                        /*val url = "http://www.coren.rn.gov.br/"
                        Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                            startActivity(this)
                        }
                        finish()*/
                        webview.loadUrl("http://www.coren.rn.gov.br/")
                    }
                    22 ->{
                        /*val url = "https://www.portalcoren-rs.gov.br/"
                        Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                            startActivity(this)
                        }
                        finish()*/
                        webview.loadUrl("https://www.portalcoren-rs.gov.br/")
                    }
                    23 ->{
                        /*val url = "http://www.coren-ro.org.br/"
                        Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                            startActivity(this)
                        }
                        finish()*/
                        webview.loadUrl("http://www.coren-ro.org.br/")
                    }
                    24 ->{
                        /*val url = "http://www.corenrr.com.br/"
                        Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                            startActivity(this)
                        }
                        finish()*/
                        webview.loadUrl("http://www.corenrr.com.br/")
                    }
                    25 ->{
                        /*val url = "http://www.corensc.gov.br/"
                        Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                            startActivity(this)
                        }
                        finish()*/
                        webview.loadUrl("http://www.corensc.gov.br/")
                    }
                    26 ->{
                        /*val url = "https://portal.coren-sp.gov.br/"
                        Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                            startActivity(this)
                        }
                        finish()*/
                        webview.loadUrl("https://portal.coren-sp.gov.br/")
                    }
                    27 ->{
                        /*val url = "http://se.corens.portalcofen.gov.br/"
                        Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                            startActivity(this)
                        }
                        finish()*/
                        webview.loadUrl("http://se.corens.portalcofen.gov.br/")
                    }
                    28 ->{
                        /*val url = "http://to.corens.portalcofen.gov.br/"
                        Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                            startActivity(this)
                        }
                        finish()*/
                        webview.loadUrl("http://to.corens.portalcofen.gov.br/")
                    }
                }
            }
        }
    }

    //Botão de voltar no ToolBar, retorna a home anterior a activity
    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        val id = item!!.itemId
        return when (id) {
            android.R.id.home -> {
                finish()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

}
