package com.example.maxsaldanha.guiadebolsodaenfermagem.adapter

import android.content.Context
import androidx.recyclerview.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.CompoundButton
import android.widget.TextView
import com.example.maxsaldanha.guiadebolsodaenfermagem.R
import com.example.maxsaldanha.guiadebolsodaenfermagem.activityprincipais.MainActivityAgenda
import com.example.maxsaldanha.guiadebolsodaenfermagem.domain.Plantao

class RecyclerViewPlantaoAdapter (
        private val context: Context,
        private val plantaoList: List<Plantao>) :
        RecyclerView.Adapter<RecyclerViewPlantaoAdapter.ViewHolder>() {


    override fun onCreateViewHolder(
            parent: ViewGroup,
            viewType: Int) : ViewHolder {

        val v = LayoutInflater
                .from(context)
                .inflate(R.layout.item_agenda, parent, false)

        return ViewHolder(v)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.setData(plantaoList[position])
    }

    override fun getItemCount(): Int {
        return plantaoList.size
    }

    inner class ViewHolder(itemView: View) :
            RecyclerView.ViewHolder(itemView),
            CompoundButton.OnCheckedChangeListener {

        var ivPriority: TextView
        var tvDate: TextView
        var tvMes:TextView
        var tvAno:TextView
        var tvTask: TextView
        var tvDuration: TextView
        var cbDone: CheckBox

        init {
            ivPriority = itemView.findViewById(R.id.iv_ic_priority)
            tvDate = itemView.findViewById(R.id.tv_date)
            tvMes = itemView.findViewById(R.id.tv_mes)
            tvAno = itemView.findViewById(R.id.tv_ano)
            tvTask = itemView.findViewById(R.id.tv_task)
            tvDuration = itemView.findViewById(R.id.tv_duration)
            cbDone = itemView.findViewById(R.id.cb_done)
            cbDone.setOnCheckedChangeListener(this)
        }

        fun setData(plantao: Plantao) {
            ivPriority.text = context.resources.getStringArray(R.array.priorities)[plantao.priority]
            tvDate.text = context.resources.getStringArray(R.array.days_31)[plantao.dia]
            tvMes.text = context.resources.getStringArray(R.array.months)[plantao.mes]
            tvAno.text = context.resources.getStringArray(R.array.years)[plantao.ano]
            tvTask.text = plantao.task
            tvDuration.text = context.resources.getStringArray(R.array.durations)[plantao.duration]
            cbDone.isChecked = false
        }

        override fun onCheckedChanged(checkBox: CompoundButton?, status: Boolean) {
            val ma = (context as MainActivityAgenda)

            if( !ma.isRecyclerAnimationg() ){

                val dialog = androidx.appcompat.app.AlertDialog.Builder(ma, R.style.MyDialogTheme)
                        .setTitle("Agenda de Plantões")
                        .setMessage("\n Dejesa excluir o plantão?")
                        .setPositiveButton("Sim") { _, _ ->
                            ma.removeFromList( adapterPosition )
                        }
                        .setNegativeButton("Não") { _, _ -> }
                dialog.show()
            }
            else{
                (checkBox as CheckBox).isChecked = false
            }
        }
    }
}

