package com.example.maxsaldanha.guiadebolsodaenfermagem.data

import android.content.Context
import com.example.maxsaldanha.guiadebolsodaenfermagem.R
import com.example.maxsaldanha.guiadebolsodaenfermagem.domain.Doc

class Databasegenital {
    companion object{
        fun getDocs() = listOf(
                Doc("SISTEMA GENITAL.pdf", R.drawable.manuaistecnicos, "SISTEMA GENITAL"),
                Doc("DUCTO DEFERENTE.pdf", R.drawable.manuaistecnicos, "DUCTO DEFERENTE"),
                Doc("DUCTO EJACULATÓRIO.pdf", R.drawable.manuaistecnicos, "DUCTO EJACULATÓRIO"),
                Doc("EPIDÍDIMO.pdf", R.drawable.manuaistecnicos, "EPIDÍDIMO"),
                Doc("ESCROTO.pdf", R.drawable.manuaistecnicos, "ESCROTO"),
                Doc("GLÂNDULA BULBOURETRAL.pdf", R.drawable.manuaistecnicos, "GLÂNDULA BULBOURETRAL"),
                Doc("ÓRGÃOS EXTERNOS FEMININOS.pdf", R.drawable.manuaistecnicos, "ÓRGÃOS EXTERNOS FEMININOS"),
                Doc("OVÁRIOS.pdf", R.drawable.manuaistecnicos, "OVÁRIOS"),
                Doc("PÊNIS.pdf", R.drawable.manuaistecnicos, "PÊNIS"),
                Doc("PRÓSTATA.pdf", R.drawable.manuaistecnicos, "PRÓSTATA"),
                Doc("TESTÍCULOS.pdf", R.drawable.manuaistecnicos, "TESTÍCULOS"),
                Doc("TUBAS UTERINAS.pdf", R.drawable.manuaistecnicos, "TUBAS UTERINAS"),
                Doc("ÚTERO.pdf", R.drawable.manuaistecnicos, "ÚTERO"),
                Doc("VAGINA.pdf", R.drawable.manuaistecnicos, "VAGINA"),
                Doc("VESÍCULA SEMINAL.pdf", R.drawable.manuaistecnicos, "VESÍCULA SEMINAL")

        )fun saveActualPageSP(context: Context, key: String, page: Int ){
            context
                    .getSharedPreferences("PREF", Context.MODE_PRIVATE)
                    .edit()
                    .putInt("$key-page", page)
                    .apply()
        }

        fun getActualPageSP(context: Context, key: String )
                = context
                .getSharedPreferences("PREF", Context.MODE_PRIVATE)
                .getInt("$key-page", 0)

    }
}
