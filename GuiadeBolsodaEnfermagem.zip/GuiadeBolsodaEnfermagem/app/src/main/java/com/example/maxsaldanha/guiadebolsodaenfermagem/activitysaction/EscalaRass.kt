package com.example.maxsaldanha.guiadebolsodaenfermagem.activitysaction

import android.graphics.Color
import android.os.Build
import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import android.view.MenuItem
import android.widget.AdapterView
import android.widget.GridView
import com.example.maxsaldanha.guiadebolsodaenfermagem.Calculos
import com.example.maxsaldanha.guiadebolsodaenfermagem.R
import com.example.maxsaldanha.guiadebolsodaenfermagem.adapter.GridViewItemAdapterRass
import com.example.maxsaldanha.guiadebolsodaenfermagem.domain.ItemMenuGrid

/*Informativo:
        É uma escala utilizada para avaliar o grau de sedação e agitação de um paciente que
        necessite de cuidados críticos ou esteja sob agitação psicomotora.

        Referências:
        Ely E, Truman B, Shintani A, et al. Monitoring Sedation Status Over Time in ICU Patients:
        Reliability and Validity of the Richmond Agitation-Sedation Scale (RASS).
        JAMA. 2003;289(22):2983-2991. doi:10.1001/jama.289.22.2983.
         */

class EscalaRass:
        AppCompatActivity(),
        Calculos{

    private var adapterGridView: GridViewItemAdapterRass? = null //Adapta o item no GridView
    private var itemList = ArrayList<ItemMenuGrid>() //Array com base na classe parâmetro

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_rass)

        ///seta a cor Windows StatusBar
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.statusBarColor = Color.rgb(64,174,203)
        }

        //ToolBar não default
        val toolbar:Toolbar=findViewById(R.id.my_toolbar)
        setSupportActionBar(toolbar)

        //Configurações da Toolbar
        supportActionBar!!.title="ESCALA RASS"
        supportActionBar!!.setHomeButtonEnabled(true) // Habilita botão de voltar
        supportActionBar!!.setDisplayHomeAsUpEnabled(true) // Torna o iconce visível
        supportActionBar!!.setDisplayShowHomeEnabled(true) // Torna o botão visível

        //Array de preenchimento do GridView
        itemList.add(ItemMenuGrid("Combativo, violento, representando risco para a equipe.",
                R.drawable.rass1))
        itemList.add(ItemMenuGrid("Puxa ou remove tubos ou catéteres, agressivo verbalmente.",
                R.drawable.rass2))
        itemList.add(ItemMenuGrid("Movimentos despropositados frequentes, briga com o ventilador.",
                R.drawable.rass3))
        itemList.add(ItemMenuGrid("Apresenta movimentos, mas que não são agressivos ou vigorosos.",
                R.drawable.rass4))
        itemList.add(ItemMenuGrid("Alerta e calmo.",
                R.drawable.rass5))
        itemList.add(ItemMenuGrid("Adormecido, acorda ao ser chamado, olhos abertos por mais de 10 seg.",
                R.drawable.rass6))
        itemList.add(ItemMenuGrid("Despertar precoce ao estímulo verbal, contato visual por menos de 10 seg.",
                R.drawable.rass7))
        itemList.add(ItemMenuGrid("Movimentação ou abertura ocular ao estímulo verbal, sem contato visual.",
                R.drawable.rass8))
        itemList.add(ItemMenuGrid("Sem resposta: ao ser chamado, movimentação ou abertura ocular.",
                R.drawable.rass9))
        itemList.add(ItemMenuGrid("Sem resposta a estímulo verbal ou físico",
                R.drawable.rass10))

        //Definição da adapterGridView preenchida na classe com items referenciados
        adapterGridView = GridViewItemAdapterRass(this,itemList)

        val gridview: GridView = findViewById(R.id.gridview) //Instância o gridview ao id no xml

        gridview.adapter=adapterGridView //Seta o modelo da adapterGridView no GridView

        gridview.onItemClickListener = AdapterView.OnItemClickListener { _, _, position, _ ->
            when(position){
                0 ->{

                    val dialog = AlertDialog.Builder(this, R.style.MyDialogTheme)
                            .setTitle("COMBATIVO")
                            .setMessage("\n Paciente com RASS +4")
                            .setNegativeButton("Fechar") { _, _ -> }
                    dialog.show()
                }
                1 ->{
                    val dialog = AlertDialog.Builder(this, R.style.MyDialogTheme)
                            .setTitle("MUITO AGITADO")
                            .setMessage("\n Paciente com RASS +3")
                            .setNegativeButton("Fechar") { _, _ -> }
                    dialog.show()
                }
                2 ->{
                    val dialog = AlertDialog.Builder(this, R.style.MyDialogTheme)
                            .setTitle("AGITADO")
                            .setMessage("\n Paciente com RASS +2")
                            .setNegativeButton("Fechar") { _, _ -> }
                    dialog.show()
                }
                3 ->{
                    val dialog = AlertDialog.Builder(this, R.style.MyDialogTheme)
                            .setTitle("INQUIETO")
                            .setMessage("\n Paciente com RASS +1")
                            .setNegativeButton("Fechar") { _, _ -> }
                    dialog.show()
                }
                4 ->{
                    val dialog = AlertDialog.Builder(this, R.style.MyDialogTheme)
                            .setTitle("ALERTA E CALMO")
                            .setMessage("\n Paciente com RASS 0")
                            .setNegativeButton("Fechar") { _, _ -> }
                    dialog.show()
                }
                5 ->{
                    val dialog = AlertDialog.Builder(this, R.style.MyDialogTheme)
                            .setTitle("SONOLENTO")
                            .setMessage("\n Paciente com RASS -1")
                            .setNegativeButton("Fechar") { _, _ -> }
                    dialog.show()
                }
                6 ->{
                    val dialog = AlertDialog.Builder(this, R.style.MyDialogTheme)
                            .setTitle("SEDAÇÃO LEVE")
                            .setMessage("\n Paciente com RASS -2")
                            .setNegativeButton("Fechar") { _, _ -> }
                    dialog.show()
                }
                7 ->{
                    val dialog = AlertDialog.Builder(this, R.style.MyDialogTheme)
                            .setTitle("SEDAÇÃO MODERADA")
                            .setMessage("\n Paciente com RASS -3")
                            .setNegativeButton("Fechar") { _, _ -> }
                    dialog.show()
                }
                8 ->{
                    val dialog = AlertDialog.Builder(this, R.style.MyDialogTheme)
                            .setTitle("SEDAÇÃO INTENSA")
                            .setMessage("\n Paciente com RASS -4")
                            .setNegativeButton("Fechar") { _, _ -> }
                    dialog.show()
                }
                9 ->{
                    val dialog = AlertDialog.Builder(this, R.style.MyDialogTheme)
                            .setTitle("NÃO RESPONDE")
                            .setMessage("\n Paciente com RASS -5")
                            .setNegativeButton("Fechar") { _, _ -> }
                    dialog.show()
                }
            }
        }
    }

    //Botão de voltar no ToolBar, retorna a home anterior a activity
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                finish()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
    //Método abstrato, herdado da interface
    override fun calcular() {

        try {
            /*Classe não requer cálculo, nem operação, apenas demostração do valor RASS atrelado ao sinal
        selecionado na tabela.

        Assinatura para cumprimento de padrão
        */

        }
        catch (e:Exception){
            e.message
        }
    }
}