package com.example.maxsaldanha.guiadebolsodaenfermagem.data

import android.content.Context
import com.example.maxsaldanha.guiadebolsodaenfermagem.R
import com.example.maxsaldanha.guiadebolsodaenfermagem.domain.Doc

class Databaserespiratorio {
    companion object{
        fun getDocs() = listOf(
                Doc("BRÔNQUIOS.pdf", R.drawable.manuaistecnicos, "BRÔNQUIOS"),
                Doc("FARINGE.pdf", R.drawable.manuaistecnicos, "FARINGE"),
                Doc("LARINGE.pdf", R.drawable.manuaistecnicos, "LARINGE"),
                Doc("NARIZ.pdf", R.drawable.manuaistecnicos, "NARIZ"),
                Doc("TRAQUEIA.pdf", R.drawable.manuaistecnicos, "TRAQUEIA")
        )fun saveActualPageSP(context: Context, key: String, page: Int ){
            context
                    .getSharedPreferences("PREF", Context.MODE_PRIVATE)
                    .edit()
                    .putInt("$key-page", page)
                    .apply()
        }

        fun getActualPageSP(context: Context, key: String )
                = context
                .getSharedPreferences("PREF", Context.MODE_PRIVATE)
                .getInt("$key-page", 0)

    }
}
