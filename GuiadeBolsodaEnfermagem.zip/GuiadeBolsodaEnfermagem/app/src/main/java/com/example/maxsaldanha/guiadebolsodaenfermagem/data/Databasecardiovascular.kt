package com.example.maxsaldanha.guiadebolsodaenfermagem.data

import android.content.Context
import com.example.maxsaldanha.guiadebolsodaenfermagem.R
import com.example.maxsaldanha.guiadebolsodaenfermagem.domain.Doc

class Databasecardiovascular {
    companion object{
        fun getDocs() = listOf(

                Doc("SISTEMA CARDIOVASCULAR.pdf", R.drawable.manuaistecnicos, "SISTEMA CARDIOVASCULAR"),
                Doc("CORAÇÃO.pdf", R.drawable.manuaistecnicos, "CORAÇÃO"),
                Doc("SANGUE.pdf", R.drawable.manuaistecnicos, "SANGUE"),
                Doc("SISTEMA ARTERIAL.pdf", R.drawable.manuaistecnicos, "SISTEMA ARTERIAL"),
                Doc("SISTEMA VENOSO.pdf", R.drawable.manuaistecnicos, "SISTEMA VENOSO"),
                Doc("VASOS SANGUÍNEOS.pdf", R.drawable.manuaistecnicos, "VASOS SANGUÍNEOS")

        )fun saveActualPageSP(context: Context, key: String, page: Int ){
            context
                    .getSharedPreferences("PREF", Context.MODE_PRIVATE)
                    .edit()
                    .putInt("$key-page", page)
                    .apply()
        }

        fun getActualPageSP(context: Context, key: String )
                = context
                .getSharedPreferences("PREF", Context.MODE_PRIVATE)
                .getInt("$key-page", 0)

    }
}
