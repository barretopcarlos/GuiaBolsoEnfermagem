package com.example.maxsaldanha.guiadebolsodaenfermagem.activityfragment

import android.app.Dialog
import android.os.Bundle
import androidx.fragment.app.DialogFragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.TextView
import com.example.maxsaldanha.guiadebolsodaenfermagem.R
import com.example.maxsaldanha.guiadebolsodaenfermagem.activityprincipais.MainActivityAgenda
import com.example.maxsaldanha.guiadebolsodaenfermagem.domain.Plantao
import kotlinx.android.synthetic.main.activity_fragment_cadastro_plantao.*
import java.util.*

/*
    Classe que gerencia o fragmento aberto pela classe da agenda no botão de ação, button floating,
    quer será exibida sobre a classe principal da agenda.
 */

@Suppress("NULLABILITY_MISMATCH_BASED_ON_JAVA_ANNOTATIONS")
class PlantaoDialogFragment:
        DialogFragment(),
        View.OnClickListener,
        AdapterView.OnItemSelectedListener {

    companion object {
        val KEY = "activity_fragment_cadastro_plantao"
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        /*
      Para que seja removida a barra de topo do dialog em aparelhos com o Android abaixo da API 21.
         */
        val dialog = super.onCreateDialog(savedInstanceState)
        dialog.window!!.requestFeature(Window.FEATURE_NO_TITLE)
        return dialog
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        super.onCreateView(inflater, container, savedInstanceState)
        return inflater.inflate(R.layout.activity_fragment_cadastro_plantao, null, false)
    }

    override fun onResume() {
        super.onResume()
        bt_create_task.setOnClickListener(this)
        sp_months.onItemSelectedListener = this
    }

    override fun onClick(view: View?) {

        val calendar = Calendar.getInstance()
        calendar.set(
                getSelectedYear(),
                sp_months.selectedItemPosition,
                sp_days.selectedItemPosition,
                0,
                0,
                0
        )

        val toDo = Plantao(
                calendar.timeInMillis,
                sp_days.selectedItemPosition,
                sp_months.selectedItemPosition,
                sp_years.selectedItemPosition,
                et_task.text.toString(),
                sp_duration.selectedItemPosition,
                sp_priority.selectedItemPosition
        )

        (activity as MainActivityAgenda).addToList( toDo )
        dismiss()
    }

    private fun getSelectedYear() = (sp_years.selectedView as TextView).text.toString().toInt()

    override fun onItemSelected(
            parentView: AdapterView<*>?,
            view: View?,
            position: Int,
            id: Long) {

        val arrayDays = getArrayDaysResource( position )
        val adapter = activity?.let {
            ArrayAdapter.createFromResource(
                    it,
                arrayDays,
                android.R.layout.simple_spinner_item )
        }

        if (adapter != null) {
            adapter.setDropDownViewResource(R.layout.spinner_dropdown_item)
        }
        sp_days.adapter = adapter
    }
//Seleciona o array de dias de acordo com mês.
    private fun getArrayDaysResource( month: Int )
            = if( month in arrayOf(1,3,5,7,8,10,12) ){
        R.array.days_31
    }
    else if( month in arrayOf(4,6,9,11) ){
        R.array.days_30
    }
    else{
        if( isLeapYear( getSelectedYear() ) ){
            R.array.days_29
        }
        else{
            R.array.days_28
        }
    }
//Função testa se o ano é bissexto
     private fun isLeapYear(year: Int)
            = if (year % 4 == 0) {
        if (year % 100 == 0) {
            year % 400 == 0
        }
        else{
            true
        }
    }
    else{
        false
    }
//Função padrão exigida pela biblioteca
    override fun onNothingSelected(p0: AdapterView<*>?) {}
}