package com.example.maxsaldanha.guiadebolsodaenfermagem.activitysaction

import android.graphics.Color
import android.os.Build
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import android.view.MenuItem
import android.view.View
import android.widget.EditText
import com.example.maxsaldanha.guiadebolsodaenfermagem.Calculos
import com.example.maxsaldanha.guiadebolsodaenfermagem.R
import java.lang.Float.parseFloat
import java.lang.Integer.parseInt
import java.text.DecimalFormat

/*Informativo:
Cálculo da hidratação: Fórmula de Parkland = 2 a 4ml x % SCQ x peso (kg).

Fonte: http://bvsms.saude.gov.br/bvs/publicacoes/cartilha_tratamento_emergencia_queimaduras.pdf
 */

class ReposicaoVolemica:
        AppCompatActivity(),
        Calculos {

    //Variáveis, componentes do XML
    private lateinit var sQ: EditText
    private lateinit var pesoAP: EditText
    private lateinit var qtdml:EditText
    private lateinit var resultadoRV: EditText


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_reposicao_volemica)

        //seta a cor Windows StatusBar
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.statusBarColor = Color.rgb(64,174,203)
        }

        //ToolBar não default
        val toolbar:Toolbar=findViewById(R.id.my_toolbar)
        setSupportActionBar(toolbar)

        //Configurações da Toolbar
        supportActionBar!!.title="REPOSIÇÃO VOLÊMICA" // Título
        supportActionBar!!.setHomeButtonEnabled(true) // Habilita botão de voltar
        supportActionBar!!.setDisplayHomeAsUpEnabled(true) // Torna o iconce visível
        supportActionBar!!.setDisplayShowHomeEnabled(true) // Torna o botão visível

        //Captura o dado informado no XML
        sQ=findViewById(R.id.etSQ)
        pesoAP=findViewById(R.id.etPesoRV)
        qtdml=findViewById(R.id.qtdml)
        resultadoRV=findViewById(R.id.resultadoRV)

        //Método focus para capturar o dado inserido após a confirmação, sem botão de ação.
        sQ.onFocusChangeListener= View.OnFocusChangeListener{ _, _ ->
            calcular()
        }
        pesoAP.onFocusChangeListener = View.OnFocusChangeListener { _, _ ->
            calcular()
        }
        qtdml.onFocusChangeListener = View.OnFocusChangeListener { _, _ ->
            calcular()
        }
    }

    //Botão de voltar no ToolBar, retorna a home anterior a activity
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id = item.itemId
        return when (id) {
            android.R.id.home -> {
                finish()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }

    }
    //Método abstrato, herdado da interface
    override fun calcular() {

        try {
            //Conversão de tipo de variável
            val sqcal:Int = parseInt(sQ.text.toString())
            val pesocal:Float = parseFloat(pesoAP.text.toString())
            val qtdml:Int= parseInt(qtdml.text.toString())

            when {
                sqcal > 100 || pesocal > 500 || qtdml > 4 || qtdml < 2 -> resultadoRV.setText("Verifique o valor digitado.")
                else -> {

                    val repor:Float =qtdml *sqcal * pesocal //Fórmula
                    val decimalFormat=DecimalFormat(".#") //Configura a quantidade de casas decimais

                    resultadoRV.setText("Infundir: "+decimalFormat.format(repor)+" ml") //Resultado setado num EditText

                }
            }
        }
        catch (e: Exception) {
            e.message
        }
    }
}