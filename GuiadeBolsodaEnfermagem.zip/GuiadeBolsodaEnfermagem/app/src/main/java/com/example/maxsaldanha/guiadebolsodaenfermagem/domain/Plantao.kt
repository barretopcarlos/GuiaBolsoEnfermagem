package com.example.maxsaldanha.guiadebolsodaenfermagem.domain

class Plantao (
        val date:Long,
        var dia: Int,
        var mes: Int,
        var ano: Int,
        val task: String,
        val duration : Int,
        val priority: Int) {

    companion object {
        @JvmField val TO_DO_LIST_KEY = "to_do_list"
    }

    fun getDateInSeconds() = date / 1000

}