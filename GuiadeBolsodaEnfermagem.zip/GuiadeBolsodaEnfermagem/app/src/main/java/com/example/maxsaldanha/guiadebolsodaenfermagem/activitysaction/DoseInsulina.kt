package com.example.maxsaldanha.guiadebolsodaenfermagem.activitysaction

import android.graphics.Color
import android.os.Build
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import android.view.MenuItem
import android.widget.EditText
import com.example.maxsaldanha.guiadebolsodaenfermagem.Calculos
import com.example.maxsaldanha.guiadebolsodaenfermagem.R

/* Informativo:
Na regra de três simples trabalha-se com três elementos conhecidos, e a partir deles determina-se o
4o elemento. Frasco de 100 UI (Unidades Internacional), Seringa 1 ml

Fonte: http://portalarquivos2.saude.gov.br/images/pdf/2018/marco/19/Portaria-Conjunta-n-8.pdf
 */

class DoseInsulina:
        AppCompatActivity(),
        Calculos {

    //Variáveis, componentes do XML
    private lateinit var doseInsulin: EditText
    private lateinit var resultadoInsulinML: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dose_insulina)

        //seta a cor Windows StatusBar
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.statusBarColor = Color.rgb(64,174,203)
        }

        //ToolBar não default
        val toolbar:Toolbar=findViewById(R.id.my_toolbar)
        setSupportActionBar(toolbar)

        //Configurações da Toolbar
        supportActionBar!!.title="INSULINA"
        supportActionBar!!.setHomeButtonEnabled(true) // Habilita botão de voltar
        supportActionBar!!.setDisplayHomeAsUpEnabled(true) // Torna o iconce visível
        supportActionBar!!.setDisplayShowHomeEnabled(true) // Torna o botão visível

        //Captura o dado informado no XML
        doseInsulin=findViewById(R.id.et_dose_Insulina)
        resultadoInsulinML=findViewById(R.id.resultado_insulin_ML)

        //Método focus para capturar o dado inserido após a confirmação, sem botão de ação.
       /* doseInsulin.onFocusChangeListener= View.OnFocusChangeListener{ _, _ ->
            calcular()
        }*/
        doseInsulin.setOnClickListener {
            calcular()
        }
    }

    //Botão de voltar no ToolBar, retorna a home anterior a activity
    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        val id = item!!.itemId
        return when (id) {
            android.R.id.home -> {
                finish()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    //Método abstrato, herdado da interface
    override fun calcular() {

        try {
            //Conversão de tipo de variável
            val dose: Float = java.lang.Float.parseFloat(doseInsulin.text.toString())

            if (dose>100){

                resultadoInsulinML.setText("Verifique o valor digitado!")

            }
            else{
                //Fórmula
                val resultadoML: Float = dose * 1 / 100

                //Resultado setado num EditText
                resultadoInsulinML.setText("""Aplicar: $resultadoML ML""")

            }

        }
        catch (e : Exception){
            e.message
        }
    }
}